# Reproducibility package

## Study

**Censoring-Aware Temporal Validation of Historical EPSS for Subsequent CISA KEV Inclusion**

This archive contains the analysis protocol, processed study cohorts, analysis code, machine-readable results, and manuscript figures for the submitted study. It deliberately excludes third-party literature packages, credentials, and the bulk monthly and weekly EPSS archives.

## Public data sources

- NVD CVE 2.0 feeds: CVE identifiers and publication timestamps.
- CISA Known Exploited Vulnerabilities catalog: `dateAdded` as the observable catalog-inclusion date.
- FIRST EPSS historical archives: historical score snapshots assigned at the publication+30-day landmark.

KEV `dateAdded` is not interpreted as the date of first exploitation. Vulnerabilities not observed in KEV by 16 July 2026 remain administratively right-censored.

## Included directories

- `02_protocol/`: frozen analysis plan.
- `03_data/processed/`: the analysis-ready NVD-KEV event cohort, compressed monthly-primary and weekly-sensitivity landmark cohorts, and the future EPSS snapshot used only for the leakage negative control.
- `03_data/manifests/`: the URL, size, and checksum manifest for the 237 weekly EPSS snapshots used in the archive-cadence sensitivity analysis.
- `04_code/`: landmark-cohort construction from the supplied event cohort, validation, sensitivity, workload simulation, uncertainty, leakage-audit, supporting-diagnostic, table, and figure scripts.
- `05_results/`: machine-readable and narrative result files, supporting diagnostics, tables, and figures.

The submission-document builder is not included because it contains author and local runtime metadata and is not required to reproduce the scientific results. The archive begins with the supplied analysis-ready NVD-KEV event cohort; the earlier source-ingestion code used to assemble that file from raw NVD and KEV downloads is not included. The bulk monthly and weekly EPSS snapshot collections are omitted because they can be reacquired from FIRST; the weekly downloader and its generated manifest are included. The supplied landmark cohorts permit all statistical analyses to be rerun without those bulk archives. Rebuilding a landmark cohort with `strict_landmark_replication.py` requires the supplied event cohort and reacquired historical EPSS snapshots.

## Recommended execution order

Starting from the supplied processed cohorts:

1. `temporal_validation.py`
2. `block_bootstrap_validation.py`
3. `temporal_leakage_audit.py`
4. `operational_capacity_evaluation.py`
5. `sensitivity_analyses.py`
6. `compare_monthly_weekly.py`
7. `supporting_diagnostics.py`
8. `make_manuscript_tables.py`
9. `make_figures.py`

`strict_landmark_replication.py` rebuilds a landmark cohort from the supplied NVD-KEV event cohort and additionally requires a directory of historical EPSS snapshots.

The scripts document their project-relative inputs and outputs through `--help`. The monthly block bootstrap used 500 replicates with seed `20260718`; the weekly block bootstrap used 500 replicates with seed `20260719`; and the operational-capacity bootstrap used 500 replicates with seed `20260719`. The processed cohorts and frozen result files permit result inspection and rerunning of the reported statistical analyses without downloading the raw archives.

The supporting diagnostics report a development-model hazard-ratio interval, a development-only no-covariate Brier reference, publication-month event counts, and explicit complete-month ranges for workload analyses. They do not alter the cohort, endpoint, censoring rule, temporal split, or headline discrimination estimates.

## Software environment

Python 3 with the package versions pinned in `requirements.txt`. The principal analysis environment used NumPy 2.0.2, pandas 2.3.3, scikit-learn 1.5.2, scikit-survival 0.23.1, lifelines 0.30.0, SciPy 1.13.1, and Matplotlib 3.9.4.

## Integrity and safety

`SHA256SUMS.txt` lists SHA-256 hashes for every packaged file other than the checksum file itself. Before creation, the included folders were scanned for common credential patterns, private-key markers, personal email addresses, and absolute user paths. No such material is included.

## License note

NVD, CISA KEV, and FIRST EPSS remain subject to their providers' terms. This archive republishes only the processed study cohorts and derived results needed for research reproducibility.
