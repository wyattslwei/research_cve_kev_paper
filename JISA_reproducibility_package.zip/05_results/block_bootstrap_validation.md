# Publication-month block bootstrap

Replicates: **500**; seed: **20260718**.
The 2022-2023 Cox model is locked. Validation and test months are resampled as whole blocks.

## Temporal validation (95% percentile intervals)

| Split | Metric | Point estimate | 95% CI | Valid replicates |
|---|---|---:|---:|---:|
| validation_2024 | Uno C, 365d | 0.6374 | 0.5587-0.7226 | 499 |
| validation_2024 | Dynamic AUC, 30d | 0.5894 | 0.3886-0.8253 | 499 |
| validation_2024 | Dynamic AUC, 90d | 0.5586 | 0.4445-0.6744 | 499 |
| validation_2024 | Dynamic AUC, 180d | 0.6094 | 0.5532-0.6806 | 499 |
| validation_2024 | Dynamic AUC, 365d | 0.6375 | 0.5588-0.7228 | 499 |
| validation_2024 | IBS, 30-365d | 0.0011 | 0.0007-0.0014 | 499 |
| validation_2024 | Calibration slope | 1.1862 | 0.9877-1.3954 | 499 |
| test_2025 | Uno C, 365d | 0.7258 | 0.6641-0.7888 | 500 |
| test_2025 | Dynamic AUC, 30d | 0.6821 | 0.5212-0.8395 | 500 |
| test_2025 | Dynamic AUC, 90d | 0.6939 | 0.5880-0.7958 | 500 |
| test_2025 | Dynamic AUC, 180d | 0.7134 | 0.6272-0.7868 | 500 |
| test_2025 | Dynamic AUC, 365d | 0.7238 | 0.6265-0.7989 | 500 |
| test_2025 | IBS, 30-365d | 0.0011 | 0.0009-0.0013 | 500 |
| test_2025 | Calibration slope | 0.9135 | 0.7766-1.0533 | 500 |

## Development-model hazard ratio

| N | Events | Point HR | 95% month-block-bootstrap CI | Valid replicates |
|---:|---:|---:|---:|---:|
| 45,623 | 107 | 2.220 | 1.904-2.537 | 500 |

## Fixed-window censoring bias

Positive AUROC values mean that coding insufficient-follow-up CVEs as negatives inflates AUROC.

| Split | Horizon | Point naive-complete AUROC | 95% CI | Point naive-complete AP | 95% CI |
|---|---:|---:|---:|---:|---:|
| validation_2024 | 30 | 0.0000 | 0.0000-0.0000 | 0.00000 | 0.00000-0.00000 |
| validation_2024 | 90 | 0.0000 | 0.0000-0.0000 | 0.00000 | 0.00000-0.00000 |
| validation_2024 | 180 | 0.0000 | 0.0000-0.0000 | 0.00000 | 0.00000-0.00000 |
| validation_2024 | 365 | 0.0000 | 0.0000-0.0000 | 0.00000 | 0.00000-0.00000 |
| test_2025 | 30 | 0.0000 | 0.0000-0.0000 | 0.00000 | 0.00000-0.00000 |
| test_2025 | 90 | 0.0000 | 0.0000-0.0000 | 0.00000 | 0.00000-0.00000 |
| test_2025 | 180 | 0.0010 | 0.0000-0.0043 | -0.00015 | -0.00058-0.00000 |
| test_2025 | 365 | 0.0084 | -0.0150-0.0505 | -0.02035 | -0.07641--0.00747 |

## EPSS-version-specific raw-score hazard ratios

| Version | N | Events | Point HR | 95% block-bootstrap CI | Package/custom beta difference |
|---|---:|---:|---:|---:|---:|
| v2022.01.01 | 22,656 | 56 | 1.506 | 1.435-1.609 | 1.70e-10 |
| v2023.03.01 | 68,134 | 128 | 1.354 | 1.307-1.424 | 2.22e-09 |
| v2025.03.14 | 38,949 | 55 | 1.802 | 1.668-1.957 | 2.61e-09 |

## Interpretation guardrails

- Intervals are percentile block-bootstrap intervals; publication month is the resampling unit.
- External-validation intervals condition on the locked development model and quantify performance variation in a new calendar period.
- Raw EPSS hazard ratios are interpreted only within an EPSS model version; percentile is the cross-version ranking measure.
- KEV inclusion is the event. It is not interpreted as the first real-world exploitation date.
