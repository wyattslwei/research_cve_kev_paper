# Monthly-primary versus weekly-snapshot sensitivity

The monthly analysis remains the locked primary result. The Monday series is a prespecified freshness sensitivity and does not replace it.

## Cohort and score freshness

| Schedule | N | Events | Missing landmark EPSS | Median score age | P90 score age |
|---|---:|---:|---:|---:|---:|
| monthly | 129,739 | 239 | 3,156 | 14 | 26 |
| weekly | 132,068 | 240 | 827 | 4 | 6 |

## Censoring-aware discrimination

| Split | Schedule | 30d AUC (95% CI) | 90d AUC (95% CI) | 180d AUC (95% CI) | 365d AUC (95% CI) | Uno C 365d (95% CI) |
|---|---|---:|---:|---:|---:|---:|
| validation_2024 | monthly | 0.589 (0.389-0.825) | 0.559 (0.445-0.674) | 0.609 (0.553-0.681) | 0.638 (0.559-0.723) | 0.637 (0.559-0.723) |
| validation_2024 | weekly | 0.736 (0.624-0.991) | 0.665 (0.548-0.778) | 0.683 (0.595-0.780) | 0.697 (0.618-0.793) | 0.697 (0.618-0.793) |
| test_2025 | monthly | 0.682 (0.521-0.840) | 0.694 (0.588-0.796) | 0.713 (0.627-0.787) | 0.724 (0.627-0.799) | 0.726 (0.664-0.789) |
| test_2025 | weekly | 0.686 (0.541-0.815) | 0.717 (0.634-0.820) | 0.720 (0.636-0.803) | 0.751 (0.661-0.829) | 0.742 (0.670-0.814) |

## Interpretation

- Weekly snapshots reduce measurement delay and missingness; higher short-horizon AUC is therefore consistent with a freshness-sensitive signal.
- The weekly analysis uses the same landmark, event, censor date, temporal split, and metrics as the monthly primary analysis.
- Overlapping confidence intervals and the post-feasibility timing of this comparison preclude a claim that weekly is definitively superior at every horizon.
- The sensitivity supports reporting archive cadence as a design parameter rather than treating any historical EPSS lookup as equivalent.
