# Strict publication+30-day landmark replication

Administrative censor date: **2026-07-16**.
The prediction origin is exactly publication + 30 days; the predictor is the latest historical EPSS snapshot available on or before that date.

## Cohort flow

- input_rows: **133,286**
- prepublication_kev: **56**
- same_day_kev: **115**
- kev_on_or_before_landmark: **335**
- landmark_after_censor: **0**
- no_valid_snapshot: **0**
- missing_epss: **3,156**
- kev_after_censor_treated_censored: **0**
- analysis_rows: **129,739**
- observed_events: **239**

## Dedicated-package Cox replication

| Analysis | N | Events | lifelines HR (Efron) | 95% CI | scikit-survival HR (Breslow) | PH test p |
|---|---:|---:|---:|---:|---:|---:|
| All EPSS versions | 129,739 | 239 | 1.880 | 1.711-2.066 | 1.880 | 0.156 |
| EPSS v3 only | 68,134 | 128 | 1.355 | 1.310-1.400 | 1.354 | 0.316 |
| v2022.01.01 | 22,656 | 56 | NA | NA | 1.506 | NA |
| v2023.03.01 | 68,134 | 128 | 1.355 | 1.310-1.400 | 1.354 | 0.316 |
| v2025.03.14 | 38,949 | 55 | 1.802 | 1.648-1.971 | 1.802 | 0.403 |

## Full-cohort fixed-window diagnostics

| Horizon | Naive N | Naive AUROC | Complete N | Complete AUROC | Complete AP | Insufficient follow-up |
|---:|---:|---:|---:|---:|---:|---:|
| 30 | 129,739 | 0.616 | 129,739 | 0.616 | 0.01423 | 0 |
| 90 | 129,739 | 0.640 | 129,739 | 0.640 | 0.01375 | 0 |
| 180 | 129,739 | 0.673 | 127,979 | 0.671 | 0.02630 | 1,760 |
| 365 | 129,739 | 0.682 | 104,255 | 0.648 | 0.03698 | 25,484 |

## Guardrails

- The event is CISA KEV catalog inclusion, not first exploitation.
- CVEs already in KEV by the exact landmark are excluded from the risk set.
- CVEs without an observed event remain right-censored.
- The full-cohort Cox estimate mixes EPSS model versions and is descriptive; the v3-only analysis is the preferred version-stable result.
- A significant proportional-hazards test requires a time-varying-effect sensitivity analysis before relying on one constant hazard ratio.
