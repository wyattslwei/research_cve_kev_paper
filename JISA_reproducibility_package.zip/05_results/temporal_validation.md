# Temporal validation and censoring-aware metrics

Development: 2022-2023; validation: 2024; locked test: 2025.
The Cox calibration model uses logit(EPSS percentile), scaled using the development period only.

## Main metrics

| Split | N | Events | Uno C (365d) | Mean dynamic AUC | Cox IBS | Null IBS | Relative reduction | Calibration slope |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| validation_2024 | 37,300 | 64 | 0.637 | 0.597 | 0.001053 | 0.001062 | 0.91% | 1.186 |
| test_2025 | 46,816 | 68 | 0.726 | 0.701 | 0.001092 | 0.001096 | 0.34% | 0.913 |

## Dynamic AUC by horizon

| Split | 30d | 90d | 180d | 365d |
|---|---:|---:|---:|---:|
| validation_2024 | 0.589 | 0.559 | 0.609 | 0.638 |
| test_2025 | 0.682 | 0.694 | 0.713 | 0.724 |

## Observed-to-predicted risk ratio

| Split | Horizon | Mean predicted risk | KM observed risk | O/P ratio |
|---|---:|---:|---:|---:|
| validation_2024 | 30 | 0.000139 | 0.000375 | 2.698 |
| validation_2024 | 90 | 0.000388 | 0.000751 | 1.935 |
| validation_2024 | 180 | 0.000619 | 0.001126 | 1.818 |
| validation_2024 | 365 | 0.000761 | 0.001448 | 1.904 |
| test_2025 | 30 | 0.000141 | 0.000534 | 3.792 |
| test_2025 | 90 | 0.000393 | 0.000876 | 2.231 |
| test_2025 | 180 | 0.000626 | 0.001135 | 1.812 |
| test_2025 | 365 | 0.000769 | 0.001536 | 1.999 |

## Interpretation guardrails

- EPSS percentile is used for cross-version discrimination because raw score scales shift across model versions.
- Brier and calibration results come from a Cox recalibration model trained only on 2022-2023.
- The no-covariate Brier reference applies the 2022-2023 Kaplan-Meier survival curve as the same prediction for every validation/test CVE.
- Fixed-window metrics and censoring-aware metrics answer different questions and are reported together rather than treated as interchangeable.
- The 2025 365-day estimate must be interpreted with its censoring burden and later block-bootstrap uncertainty.
