# Operational capacity evaluation

Ranking uses the historical EPSS percentile available at the publication+30-day landmark.
Each horizon includes only complete publication months, preventing knowledge of individual censoring status from entering the queue.

## Top-fraction recall

| Period | Horizon | Eligible N | Events | Top 0.5% recall | Top 1% recall | Top 5% recall |
|---|---:|---:|---:|---:|---:|---:|
| validation_2024 | 30 | 37,300 | 14 | 0.286 | 0.286 | 0.429 |
| validation_2024 | 90 | 37,300 | 28 | 0.179 | 0.179 | 0.321 |
| validation_2024 | 180 | 37,300 | 42 | 0.190 | 0.190 | 0.310 |
| validation_2024 | 365 | 37,300 | 54 | 0.185 | 0.185 | 0.278 |
| test_2025 | 30 | 46,816 | 25 | 0.120 | 0.120 | 0.240 |
| test_2025 | 90 | 46,816 | 41 | 0.171 | 0.195 | 0.317 |
| test_2025 | 180 | 41,577 | 46 | 0.130 | 0.152 | 0.348 |
| test_2025 | 365 | 19,416 | 29 | 0.241 | 0.241 | 0.345 |

## Monthly remediation capacity

| Period | Horizon | Capacity/month | Captured/Events | Recall (95% CI) | Precision (95% CI) | Lift | Median lead days |
|---|---:|---:|---:|---:|---:|---:|---:|
| validation_2024 | 30 | 100 | 5/14 | 0.357 (0.000-0.500) | 0.00417 (0.00000-0.00833) | 11.1 | 6 |
| validation_2024 | 30 | 500 | 6/14 | 0.429 (0.000-0.740) | 0.00100 (0.00000-0.00200) | 2.7 | 8 |
| validation_2024 | 30 | 1000 | 6/14 | 0.429 (0.000-0.693) | 0.00050 (0.00000-0.00100) | 1.3 | 8 |
| validation_2024 | 90 | 100 | 8/28 | 0.286 (0.153-0.435) | 0.00667 (0.00333-0.01083) | 8.9 | 12 |
| validation_2024 | 90 | 500 | 9/28 | 0.321 (0.130-0.500) | 0.00150 (0.00050-0.00250) | 2.0 | 12 |
| validation_2024 | 90 | 1000 | 9/28 | 0.321 (0.122-0.500) | 0.00075 (0.00025-0.00117) | 1.0 | 12 |
| validation_2024 | 180 | 100 | 11/42 | 0.262 (0.154-0.369) | 0.00917 (0.00500-0.01417) | 8.1 | 61 |
| validation_2024 | 180 | 500 | 15/42 | 0.357 (0.273-0.471) | 0.00250 (0.00150-0.00333) | 2.2 | 75 |
| validation_2024 | 180 | 1000 | 18/42 | 0.429 (0.350-0.500) | 0.00150 (0.00083-0.00200) | 1.3 | 87 |
| validation_2024 | 365 | 100 | 14/54 | 0.259 (0.147-0.365) | 0.01167 (0.00667-0.01667) | 8.1 | 78 |
| validation_2024 | 365 | 500 | 21/54 | 0.389 (0.294-0.516) | 0.00350 (0.00267-0.00450) | 2.4 | 123 |
| validation_2024 | 365 | 1000 | 25/54 | 0.463 (0.377-0.573) | 0.00208 (0.00150-0.00267) | 1.4 | 123 |
| test_2025 | 30 | 100 | 3/25 | 0.120 (0.000-0.286) | 0.00250 (0.00000-0.00500) | 4.7 | 24 |
| test_2025 | 30 | 500 | 11/25 | 0.440 (0.135-0.763) | 0.00183 (0.00058-0.00317) | 3.4 | 15 |
| test_2025 | 30 | 1000 | 11/25 | 0.440 (0.160-0.755) | 0.00092 (0.00033-0.00167) | 1.7 | 15 |
| test_2025 | 90 | 100 | 10/41 | 0.244 (0.114-0.386) | 0.00833 (0.00417-0.01333) | 9.5 | 46 |
| test_2025 | 90 | 500 | 19/41 | 0.463 (0.268-0.684) | 0.00317 (0.00183-0.00450) | 3.6 | 26 |
| test_2025 | 90 | 1000 | 20/41 | 0.488 (0.284-0.681) | 0.00167 (0.00100-0.00225) | 1.9 | 28 |
| test_2025 | 180 | 100 | 10/46 | 0.217 (0.101-0.367) | 0.00909 (0.00455-0.01545) | 8.2 | 52 |
| test_2025 | 180 | 500 | 24/46 | 0.522 (0.312-0.710) | 0.00436 (0.00236-0.00655) | 3.9 | 46 |
| test_2025 | 180 | 1000 | 27/46 | 0.587 (0.376-0.768) | 0.00245 (0.00145-0.00336) | 2.2 | 55 |
| test_2025 | 365 | 100 | 7/29 | 0.241 (0.032-0.522) | 0.01400 (0.00200-0.02800) | 9.4 | 46 |
| test_2025 | 365 | 500 | 15/29 | 0.517 (0.185-0.800) | 0.00600 (0.00200-0.01021) | 4.0 | 104 |
| test_2025 | 365 | 1000 | 15/29 | 0.517 (0.192-0.800) | 0.00300 (0.00100-0.00500) | 2.0 | 104 |

## Guardrails

- Capacity is defined per CVE publication month, not as a claim about a specific organization's patch workflow.
- Lead time is days from the fixed 30-day landmark to later KEV inclusion for captured events; it is not time to first exploitation.
- Precision is expected to be numerically low because later KEV inclusion is rare; recall, workload, lift, and number needed to review must be read together.
