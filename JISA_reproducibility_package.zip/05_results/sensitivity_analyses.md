# Timing-policy and snapshot-freshness sensitivity analyses

## Publication-origin event-time policies

Pre-publication KEV records: **56**; same-day records: **115**.

| Policy | N | Events | 30d risk | 90d risk | 180d risk | 365d risk |
|---|---:|---:|---:|---:|---:|---:|
| exclude_prepublication_day1_same_day | 133,230 | 580 | 0.00251 | 0.00311 | 0.00357 | 0.00401 |
| exclude_prepublication_and_same_day | 133,115 | 465 | 0.00165 | 0.00225 | 0.00271 | 0.00315 |
| include_all_kev_at_day1_nonincident_diagnostic | 133,286 | 636 | 0.00293 | 0.00353 | 0.00399 | 0.00443 |

All KEV inclusions on or before publication+30 days are excluded from the primary risk set. Therefore day-0 versus day-1 coding changes the descriptive publication-origin curve but not the strict day-30 landmark cohort.

## EPSS snapshot age

Snapshot age: median **14** days; 90th percentile **26** days; range **0-30** days.

### Complete-follow-up AUROC by age group

| Split | Age days | N | Events total | 90d AUROC | 180d AUROC | 365d AUROC |
|---|---:|---:|---:|---:|---:|---:|
| full_2022_2025 | 0-7 | 33,816 | 51 | 0.720 | 0.713 | 0.708 |
| full_2022_2025 | 8-14 | 36,310 | 71 | 0.668 | 0.691 | 0.658 |
| full_2022_2025 | 15-21 | 29,135 | 66 | 0.689 | 0.724 | 0.751 |
| full_2022_2025 | 22-30 | 30,478 | 51 | 0.552 | 0.652 | 0.616 |
| validation_2024 | 0-7 | 9,852 | 16 | 0.719 | 0.700 | 0.694 |
| validation_2024 | 8-14 | 10,612 | 19 | 0.568 | 0.613 | 0.613 |
| validation_2024 | 15-21 | 8,733 | 18 | 0.500 | 0.505 | 0.655 |
| validation_2024 | 22-30 | 8,103 | 11 | 0.489 | 0.625 | 0.615 |
| test_2025 | 0-7 | 12,925 | 17 | 0.787 | 0.743 | 0.744 |
| test_2025 | 8-14 | 12,063 | 20 | 0.626 | 0.651 | 0.663 |
| test_2025 | 15-21 | 10,494 | 15 | 0.848 | 0.871 | 0.882 |
| test_2025 | 22-30 | 11,334 | 16 | 0.392 | 0.567 | 0.638 |

### Version-stratified Cox interaction

| Term | HR | 95% CI | p |
|---|---:|---:|---:|
| z_logit_percentile | 2.827 | 2.459-3.250 | 2.47e-48 |
| age_per_30_days | 2.206 | 1.265-3.847 | 0.00529 |
| score_by_age | 0.740 | 0.556-0.985 | 0.0393 |

## Guardrails

- The nonincident policy that moves pre-publication events to day 1 is diagnostic only and is not used in the primary analysis.
- Same-day coding cannot affect the day-30 landmark cohort because all events on or before the landmark are excluded.
- Snapshot age is determined by the monthly archive schedule and publication timing; its interaction is not causal.
- Age-stratified AUROCs are sparse descriptive sensitivity results and are not used to choose a favorable subgroup.
