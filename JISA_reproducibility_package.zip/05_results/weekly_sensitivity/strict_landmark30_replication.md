# Strict publication+30-day landmark replication

Administrative censor date: **2026-07-16**.
The prediction origin is exactly publication + 30 days; the predictor is the latest historical EPSS snapshot available on or before that date.

## Cohort flow

- input_rows: **133,286**
- prepublication_kev: **56**
- same_day_kev: **115**
- kev_on_or_before_landmark: **335**
- landmark_after_censor: **0**
- no_valid_snapshot: **0**
- missing_epss: **827**
- kev_after_censor_treated_censored: **0**
- analysis_rows: **132,068**
- observed_events: **240**

## Dedicated-package Cox replication

| Analysis | N | Events | lifelines HR (Efron) | 95% CI | scikit-survival HR (Breslow) | PH test p |
|---|---:|---:|---:|---:|---:|---:|
| All EPSS versions | 132,068 | 240 | 2.106 | 1.944-2.281 | 2.106 | 0.344 |
| EPSS v3 only | 68,432 | 131 | 0.297 | 0.168-0.524 | 1.409 | 7.51e-77 |
| v2022.01.01 | 21,998 | 53 | NA | NA | 1.536 | NA |
| v2023.03.01 | 68,432 | 131 | 0.297 | 0.168-0.524 | 1.409 | 7.51e-77 |
| v2025.03.14 | 41,638 | 56 | 1.848 | 1.696-2.015 | 1.848 | 0.147 |

## Full-cohort fixed-window diagnostics

| Horizon | Naive N | Naive AUROC | Complete N | Complete AUROC | Complete AP | Insufficient follow-up |
|---:|---:|---:|---:|---:|---:|---:|
| 30 | 132,068 | 0.652 | 132,068 | 0.652 | 0.03672 | 0 |
| 90 | 132,068 | 0.676 | 132,068 | 0.676 | 0.02729 | 0 |
| 180 | 132,068 | 0.699 | 130,308 | 0.697 | 0.03822 | 1,760 |
| 365 | 132,068 | 0.714 | 106,307 | 0.683 | 0.05907 | 25,761 |

## Guardrails

- The event is CISA KEV catalog inclusion, not first exploitation.
- CVEs already in KEV by the exact landmark are excluded from the risk set.
- CVEs without an observed event remain right-censored.
- The full-cohort Cox estimate mixes EPSS model versions and is descriptive; the v3-only analysis is the preferred version-stable result.
- A significant proportional-hazards test requires a time-varying-effect sensitivity analysis before relying on one constant hazard ratio.
