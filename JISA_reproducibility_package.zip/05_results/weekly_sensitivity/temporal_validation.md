# Temporal validation and censoring-aware metrics

Development: 2022-2023; validation: 2024; locked test: 2025.
The Cox calibration model uses logit(EPSS percentile), scaled using the development period only.

## Main metrics

| Split | N | Events | Uno C (365d) | Mean dynamic AUC | Cox IBS | Null IBS | Relative reduction | Calibration slope |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| validation_2024 | 38,088 | 65 | 0.697 | 0.695 | 0.001024 | 0.001048 | 2.29% | 1.098 |
| test_2025 | 47,454 | 68 | 0.742 | 0.716 | 0.001077 | 0.001081 | 0.42% | 0.808 |

## Dynamic AUC by horizon

| Split | 30d | 90d | 180d | 365d |
|---|---:|---:|---:|---:|
| validation_2024 | 0.736 | 0.665 | 0.683 | 0.697 |
| test_2025 | 0.686 | 0.717 | 0.720 | 0.751 |

## Observed-to-predicted risk ratio

| Split | Horizon | Mean predicted risk | KM observed risk | O/P ratio |
|---|---:|---:|---:|---:|
| validation_2024 | 30 | 0.000119 | 0.000368 | 3.081 |
| validation_2024 | 90 | 0.000333 | 0.000735 | 2.209 |
| validation_2024 | 180 | 0.000533 | 0.001103 | 2.067 |
| validation_2024 | 365 | 0.000656 | 0.001444 | 2.201 |
| test_2025 | 30 | 0.000130 | 0.000527 | 4.053 |
| test_2025 | 90 | 0.000362 | 0.000864 | 2.388 |
| test_2025 | 180 | 0.000579 | 0.001119 | 1.934 |
| test_2025 | 365 | 0.000711 | 0.001515 | 2.130 |

## Interpretation guardrails

- EPSS percentile is used for cross-version discrimination because raw score scales shift across model versions.
- Brier and calibration results come from a Cox recalibration model trained only on 2022-2023.
- The no-covariate Brier reference applies the 2022-2023 Kaplan-Meier survival curve as the same prediction for every validation/test CVE.
- Fixed-window metrics and censoring-aware metrics answer different questions and are reported together rather than treated as interchangeable.
- The 2025 365-day estimate must be interpreted with its censoring burden and later block-bootstrap uncertainty.
