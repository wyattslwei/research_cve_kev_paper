# Publication-month block bootstrap

Replicates: **500**; seed: **20260719**.
The 2022-2023 Cox model is locked. Validation and test months are resampled as whole blocks.

## Temporal validation (95% percentile intervals)

| Split | Metric | Point estimate | 95% CI | Valid replicates |
|---|---|---:|---:|---:|
| validation_2024 | Uno C, 365d | 0.6966 | 0.6175-0.7933 | 500 |
| validation_2024 | Dynamic AUC, 30d | 0.7363 | 0.6236-0.9907 | 500 |
| validation_2024 | Dynamic AUC, 90d | 0.6652 | 0.5477-0.7781 | 500 |
| validation_2024 | Dynamic AUC, 180d | 0.6834 | 0.5947-0.7803 | 500 |
| validation_2024 | Dynamic AUC, 365d | 0.6967 | 0.6176-0.7934 | 500 |
| validation_2024 | IBS, 30-365d | 0.0010 | 0.0007-0.0014 | 500 |
| validation_2024 | Calibration slope | 1.0978 | 0.9408-1.2626 | 500 |
| test_2025 | Uno C, 365d | 0.7418 | 0.6697-0.8144 | 500 |
| test_2025 | Dynamic AUC, 30d | 0.6862 | 0.5410-0.8153 | 500 |
| test_2025 | Dynamic AUC, 90d | 0.7168 | 0.6336-0.8198 | 500 |
| test_2025 | Dynamic AUC, 180d | 0.7196 | 0.6365-0.8031 | 500 |
| test_2025 | Dynamic AUC, 365d | 0.7510 | 0.6608-0.8291 | 500 |
| test_2025 | IBS, 30-365d | 0.0011 | 0.0009-0.0012 | 500 |
| test_2025 | Calibration slope | 0.8076 | 0.6881-0.9408 | 500 |

## Development-model hazard ratio

| N | Events | Point HR | 95% month-block-bootstrap CI | Valid replicates |
|---:|---:|---:|---:|---:|
| 46,526 | 107 | 2.442 | 2.129-2.722 | 500 |

## Fixed-window censoring bias

Positive AUROC values mean that coding insufficient-follow-up CVEs as negatives inflates AUROC.

| Split | Horizon | Point naive-complete AUROC | 95% CI | Point naive-complete AP | 95% CI |
|---|---:|---:|---:|---:|---:|
| validation_2024 | 30 | 0.0000 | 0.0000-0.0000 | 0.00000 | 0.00000-0.00000 |
| validation_2024 | 90 | 0.0000 | 0.0000-0.0000 | 0.00000 | 0.00000-0.00000 |
| validation_2024 | 180 | 0.0000 | 0.0000-0.0000 | 0.00000 | 0.00000-0.00000 |
| validation_2024 | 365 | 0.0000 | 0.0000-0.0000 | 0.00000 | 0.00000-0.00000 |
| test_2025 | 30 | 0.0000 | 0.0000-0.0000 | 0.00000 | 0.00000-0.00000 |
| test_2025 | 90 | 0.0000 | 0.0000-0.0000 | 0.00000 | 0.00000-0.00000 |
| test_2025 | 180 | 0.0003 | -0.0005-0.0020 | -0.00015 | -0.00049-0.00000 |
| test_2025 | 365 | -0.0000 | -0.0120-0.0228 | -0.02207 | -0.07662--0.00749 |

## EPSS-version-specific raw-score hazard ratios

| Version | N | Events | Point HR | 95% block-bootstrap CI | Package/custom beta difference |
|---|---:|---:|---:|---:|---:|
| v2022.01.01 | 21,998 | 53 | 1.536 | 1.467-1.604 | 2.62e-12 |
| v2023.03.01 | 68,432 | 131 | 1.409 | 1.359-1.464 | 4.71e-11 |
| v2025.03.14 | 41,638 | 56 | 1.848 | 1.706-2.017 | 1.23e-11 |

## Interpretation guardrails

- Intervals are percentile block-bootstrap intervals; publication month is the resampling unit.
- External-validation intervals condition on the locked development model and quantify performance variation in a new calendar period.
- Raw EPSS hazard ratios are interpreted only within an EPSS model version; percentile is the cross-version ranking measure.
- KEV inclusion is the event. It is not interpreted as the first real-world exploitation date.
