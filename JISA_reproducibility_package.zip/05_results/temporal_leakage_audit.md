# Temporal leakage and score-scale audit

Future leakage-stress-test snapshot: **epss_scores-2026-07-01.csv.gz**.
The future score is deliberately invalid for prospective prediction and is never proposed as a model input.

## Future-snapshot leakage stress test

| Split | Metric/horizon | Historical | Future snapshot | Difference |
|---|---|---:|---:|---:|
| validation_2024 | Dynamic AUC 30d | 0.589 | 0.995 | +0.406 |
| validation_2024 | Dynamic AUC 90d | 0.559 | 0.980 | +0.421 |
| validation_2024 | Dynamic AUC 180d | 0.609 | 0.985 | +0.375 |
| validation_2024 | Dynamic AUC 365d | 0.638 | 0.985 | +0.347 |
| validation_2024 | Uno C 365d | 0.637 | 0.985 | +0.347 |
| test_2025 | Dynamic AUC 30d | 0.682 | 0.979 | +0.296 |
| test_2025 | Dynamic AUC 90d | 0.694 | 0.970 | +0.276 |
| test_2025 | Dynamic AUC 180d | 0.713 | 0.974 | +0.261 |
| test_2025 | Dynamic AUC 365d | 0.724 | 0.975 | +0.251 |
| test_2025 | Uno C 365d | 0.726 | 0.977 | +0.251 |

## Raw-score versus percentile censoring contrast (full cohort)

| Horizon | Score | Naive AUROC | Complete AUROC | Difference | Naive AP | Complete AP |
|---:|---|---:|---:|---:|---:|---:|
| 180 | epss | 0.673 | 0.671 | +0.002 | 0.02628 | 0.02630 |
| 180 | epss_percentile | 0.695 | 0.693 | +0.002 | 0.02458 | 0.02460 |
| 365 | epss | 0.682 | 0.648 | +0.034 | 0.03241 | 0.03698 |
| 365 | epss_percentile | 0.705 | 0.682 | +0.023 | 0.03183 | 0.03579 |

## Guardrails

- Any improvement from the future snapshot demonstrates retrospective information leakage, not a deployable gain.
- Comparisons use the common set of CVEs present in both historical and future snapshots.
- Raw EPSS is not assumed comparable across model versions; the raw/percentile contrast diagnoses scale drift interacting with censoring.
