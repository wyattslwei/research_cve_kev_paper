# Manuscript tables

## Table 1. Strict publication+30-day landmark cohort

| Item | Count/value |
|---|---:|
| Source CVEs published 2022-2025 | 133,286 |
| Pre-publication KEV excluded | 56 |
| KEV on or before landmark excluded | 335 |
| Missing historical EPSS excluded | 3,156 |
| Analysis cohort | 129,739 |
| Subsequent KEV inclusions | 239 |
| Right-censored observations | 129,500 |
| EPSS snapshot age, median (P90), days | 14 (26) |

| Publication period | N | Events |
|---|---:|---:|
| Development, 2022-2023 | 45,623 | 107 |
| Validation, 2024 | 37,300 | 64 |
| Held-out temporal test, 2025 | 46,816 | 68 |

## Table 2. Temporal validation discrimination and prediction error

Values in parentheses are 95% publication-month block-bootstrap percentile intervals.

| Split | 30d dynamic AUC | 90d dynamic AUC | 180d dynamic AUC | 365d dynamic AUC | Uno C, 365d | IBS, 30-365d |
|---|---:|---:|---:|---:|---:|---:|
| validation_2024 | 0.589 (0.389-0.825) | 0.559 (0.445-0.674) | 0.609 (0.553-0.681) | 0.638 (0.559-0.723) | 0.637 (0.559-0.723) | 0.001053 (0.000724-0.001440) |
| test_2025 | 0.682 (0.521-0.840) | 0.694 (0.588-0.796) | 0.713 (0.627-0.787) | 0.724 (0.627-0.799) | 0.726 (0.664-0.789) | 0.001092 (0.000881-0.001271) |

## Table 3. Calibration of the development Cox model for KEV-inclusion risk

| Split | Calibration slope (95% CI) | Horizon after landmark | Mean predicted risk | KM observed risk | Observed/predicted |
|---|---:|---:|---:|---:|---:|
| validation_2024 | 1.186 (0.988-1.395) | 30 | 0.000139 | 0.000375 | 2.70 |
|  |  | 90 | 0.000388 | 0.000751 | 1.93 |
|  |  | 180 | 0.000619 | 0.001126 | 1.82 |
|  |  | 365 | 0.000761 | 0.001448 | 1.90 |
| test_2025 | 0.913 (0.777-1.053) | 30 | 0.000141 | 0.000534 | 3.79 |
|  |  | 90 | 0.000393 | 0.000876 | 2.23 |
|  |  | 180 | 0.000626 | 0.001135 | 1.81 |
|  |  | 365 | 0.000769 | 0.001536 | 2.00 |

## Table 4. Selected 2025 publication-month-stratified workload scenarios

| Horizon after landmark | Reviews per publication month | Captured/events | Recall (95% CI) | Precision (95% CI) | Lift | N needed to review | Median landmark-to-KEV days among captured events |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 90 | 100 | 10/41 | 0.244 (0.114-0.386) | 0.0083 (0.0042-0.0133) | 9.52 | 120 | 46 |
| 90 | 500 | 19/41 | 0.463 (0.268-0.684) | 0.0032 (0.0018-0.0045) | 3.62 | 316 | 26 |
| 90 | 1000 | 20/41 | 0.488 (0.284-0.681) | 0.0017 (0.0010-0.0022) | 1.90 | 600 | 28 |
| 180 | 100 | 10/46 | 0.217 (0.101-0.367) | 0.0091 (0.0045-0.0155) | 8.22 | 110 | 52 |
| 180 | 500 | 24/46 | 0.522 (0.312-0.710) | 0.0044 (0.0024-0.0065) | 3.94 | 229 | 46 |
| 180 | 1000 | 27/46 | 0.587 (0.376-0.768) | 0.0025 (0.0015-0.0034) | 2.22 | 407 | 55 |
| 365 | 100 | 7/29 | 0.241 (0.032-0.522) | 0.0140 (0.0020-0.0280) | 9.37 | 71 | 46 |
| 365 | 500 | 15/29 | 0.517 (0.185-0.800) | 0.0060 (0.0020-0.0102) | 4.02 | 167 | 104 |
| 365 | 1000 | 15/29 | 0.517 (0.192-0.800) | 0.0030 (0.0010-0.0050) | 2.01 | 333 | 104 |

## Supplementary Table S1. Raw EPSS association within model version

| EPSS version | N | Events | HR per version-specific SD | 95% block-bootstrap CI |
|---|---:|---:|---:|---:|
| v2022.01.01 | 22,656 | 56 | 1.506 | 1.435-1.609 |
| v2023.03.01 | 68,134 | 128 | 1.354 | 1.307-1.424 |
| v2025.03.14 | 38,949 | 55 | 1.802 | 1.668-1.957 |

## Supplementary Table S2. Monthly primary versus weekly sensitivity

| Split | Schedule | N | Events | Median score age | 30d AUC | 90d AUC | 180d AUC | 365d AUC | Uno C |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| validation_2024 | monthly | 37,300 | 64 | 14 | 0.589 (0.389-0.825) | 0.559 (0.445-0.674) | 0.609 (0.553-0.681) | 0.638 (0.559-0.723) | 0.637 (0.559-0.723) |
| validation_2024 | weekly | 38,088 | 65 | 4 | 0.736 (0.624-0.991) | 0.665 (0.548-0.778) | 0.683 (0.595-0.780) | 0.697 (0.618-0.793) | 0.697 (0.618-0.793) |
| test_2025 | monthly | 46,816 | 68 | 14 | 0.682 (0.521-0.840) | 0.694 (0.588-0.796) | 0.713 (0.627-0.787) | 0.724 (0.627-0.799) | 0.726 (0.664-0.789) |
| test_2025 | weekly | 47,454 | 68 | 4 | 0.686 (0.541-0.815) | 0.717 (0.634-0.820) | 0.720 (0.636-0.803) | 0.751 (0.661-0.829) | 0.742 (0.670-0.814) |

## Supplementary Table S3. Publication-origin timing conventions

| Policy | N | Events | 30d risk | 90d risk | 180d risk | 365d risk |
|---|---:|---:|---:|---:|---:|---:|
| exclude_prepublication_day1_same_day | 133,230 | 580 | 0.00251 | 0.00311 | 0.00357 | 0.00401 |
| exclude_prepublication_and_same_day | 133,115 | 465 | 0.00165 | 0.00225 | 0.00271 | 0.00315 |
| include_all_kev_at_day1_nonincident_diagnostic | 133,286 | 636 | 0.00293 | 0.00353 | 0.00399 | 0.00443 |

## Supplementary Table S4. Publication-month event distribution in annual evaluation cohorts

| Month | N | All observed post-landmark events | Events by 30d | Events by 90d | Events by 180d | Events by 365d |
|---|---:|---:|---:|---:|---:|---:|
| 2024-01 | 2,492 | 6 | 0 | 2 | 4 | 4 |
| 2024-02 | 2,567 | 5 | 0 | 0 | 0 | 4 |
| 2024-03 | 3,086 | 4 | 0 | 1 | 1 | 3 |
| 2024-04 | 3,553 | 1 | 0 | 0 | 1 | 1 |
| 2024-05 | 4,022 | 4 | 1 | 2 | 3 | 3 |
| 2024-06 | 2,941 | 10 | 4 | 4 | 7 | 9 |
| 2024-07 | 2,980 | 3 | 0 | 2 | 2 | 2 |
| 2024-08 | 2,773 | 7 | 2 | 2 | 3 | 5 |
| 2024-09 | 2,493 | 7 | 3 | 5 | 7 | 7 |
| 2024-10 | 3,404 | 6 | 4 | 5 | 5 | 5 |
| 2024-11 | 3,649 | 6 | 0 | 2 | 4 | 6 |
| 2024-12 | 3,340 | 5 | 0 | 3 | 5 | 5 |
| 2025-01 | 4,232 | 7 | 5 | 5 | 5 | 5 |
| 2025-02 | 3,619 | 6 | 3 | 4 | 4 | 6 |
| 2025-03 | 3,938 | 9 | 2 | 3 | 6 | 9 |
| 2025-04 | 3,997 | 3 | 2 | 2 | 2 | 3 |
| 2025-05 | 3,630 | 6 | 2 | 4 | 5 | 6 |
| 2025-06 | 3,658 | 9 | 1 | 3 | 6 | 9 |
| 2025-07 | 3,657 | 6 | 2 | 2 | 3 | 6 |
| 2025-08 | 3,429 | 3 | 0 | 3 | 3 | 3 |
| 2025-09 | 4,300 | 6 | 5 | 5 | 6 | 6 |
| 2025-10 | 4,130 | 2 | 1 | 1 | 2 | 2 |
| 2025-11 | 2,987 | 4 | 0 | 3 | 4 | 4 |
| 2025-12 | 5,239 | 7 | 2 | 6 | 7 | 7 |
