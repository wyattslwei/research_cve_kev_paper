# Supporting diagnostics

These diagnostics were added as supporting robustness checks. They do not alter the prespecified estimand or headline performance results.

## Publication-month event distribution

| Month | N | All observed post-landmark events | Events by 30d | Events by 90d | Events by 180d | Events by 365d |
|---|---:|---:|---:|---:|---:|---:|
| 2024-01 | 2,492 | 6 | 0 | 2 | 4 | 4 |
| 2024-02 | 2,567 | 5 | 0 | 0 | 0 | 4 |
| 2024-03 | 3,086 | 4 | 0 | 1 | 1 | 3 |
| 2024-04 | 3,553 | 1 | 0 | 0 | 1 | 1 |
| 2024-05 | 4,022 | 4 | 1 | 2 | 3 | 3 |
| 2024-06 | 2,941 | 10 | 4 | 4 | 7 | 9 |
| 2024-07 | 2,980 | 3 | 0 | 2 | 2 | 2 |
| 2024-08 | 2,773 | 7 | 2 | 2 | 3 | 5 |
| 2024-09 | 2,493 | 7 | 3 | 5 | 7 | 7 |
| 2024-10 | 3,404 | 6 | 4 | 5 | 5 | 5 |
| 2024-11 | 3,649 | 6 | 0 | 2 | 4 | 6 |
| 2024-12 | 3,340 | 5 | 0 | 3 | 5 | 5 |
| 2025-01 | 4,232 | 7 | 5 | 5 | 5 | 5 |
| 2025-02 | 3,619 | 6 | 3 | 4 | 4 | 6 |
| 2025-03 | 3,938 | 9 | 2 | 3 | 6 | 9 |
| 2025-04 | 3,997 | 3 | 2 | 2 | 2 | 3 |
| 2025-05 | 3,630 | 6 | 2 | 4 | 5 | 6 |
| 2025-06 | 3,658 | 9 | 1 | 3 | 6 | 9 |
| 2025-07 | 3,657 | 6 | 2 | 2 | 3 | 6 |
| 2025-08 | 3,429 | 3 | 0 | 3 | 3 | 3 |
| 2025-09 | 4,300 | 6 | 5 | 5 | 6 | 6 |
| 2025-10 | 4,130 | 2 | 1 | 1 | 2 | 2 |
| 2025-11 | 2,987 | 4 | 0 | 3 | 4 | 4 |
| 2025-12 | 5,239 | 7 | 2 | 6 | 7 | 7 |

## Block structure

| Period | Publication-month blocks | Total events | Zero-event months (all follow-up) | Zero-event months at 30d |
|---|---:|---:|---:|---:|
| 2024 | 12 | 64 | 0 | 7 |
| 2025 | 12 | 68 | 0 | 2 |

## Capacity-analysis complete-month ranges

| Period | Horizon | Included months | Excluded partial months | N | Events |
|---|---:|---|---|---:|---:|
| validation_2024 | 30 | 2024-01 to 2024-12 | None | 37,300 | 14 |
| validation_2024 | 90 | 2024-01 to 2024-12 | None | 37,300 | 28 |
| validation_2024 | 180 | 2024-01 to 2024-12 | None | 37,300 | 42 |
| validation_2024 | 365 | 2024-01 to 2024-12 | None | 37,300 | 54 |
| test_2025 | 30 | 2025-01 to 2025-12 | None | 46,816 | 25 |
| test_2025 | 90 | 2025-01 to 2025-12 | None | 46,816 | 41 |
| test_2025 | 180 | 2025-01 to 2025-11 | 2025-12 | 41,577 | 46 |
| test_2025 | 365 | 2025-01 to 2025-05 | 2025-06, 2025-07, 2025-08, 2025-09, 2025-10, 2025-11, 2025-12 | 19,416 | 29 |

## Interpretation

- The annual validation/test intervals resample 12 publication-month blocks; 500 Monte Carlo draws do not create additional independent calendar blocks.
- Monthly event counts are reported to make sparse-event and zero-event-block structure visible.
- Quarterly resampling was not added because it would reduce each annual validation period from 12 blocks to only four.
- Capacity eligibility is defined at the publication-month level and never uses an individual CVE's eventual censoring status to decide whether that CVE enters the ranking set.
