#!/usr/bin/env python3
"""Generate publication-ready figures from frozen machine-readable results."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np


BLUE = "#0072B2"
ORANGE = "#D55E00"
GREEN = "#009E73"
PURPLE = "#CC79A7"
GRAY = "#6B7280"
LIGHT = "#E5E7EB"
HORIZONS = [30, 90, 180, 365]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 9,
            "axes.titlesize": 10,
            "axes.labelsize": 9,
            "xtick.labelsize": 8,
            "ytick.labelsize": 8,
            "legend.fontsize": 8,
            "figure.dpi": 150,
            "savefig.dpi": 300,
            "savefig.bbox": "tight",
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.grid": False,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def save(fig: plt.Figure, output_dir: Path, stem: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_dir / f"{stem}.png", facecolor="white")
    fig.savefig(output_dir / f"{stem}.pdf", facecolor="white")
    plt.close(fig)


def panel_label(ax: plt.Axes, label: str) -> None:
    ax.text(-0.14, 1.08, label, transform=ax.transAxes, fontsize=11, fontweight="bold")


def cohort_flow(replication: dict, output_dir: Path) -> None:
    flow = replication["flow"]
    fig, ax = plt.subplots(figsize=(9.2, 2.6))
    ax.set_axis_off()
    boxes = [
        (0.02, 0.39, 0.19, f"NVD CVEs published\n2022–2025\nN = {flow['input_rows']:,}", BLUE),
        (
            0.28,
            0.39,
            0.22,
            f"Exclusions before landmark\nPre-publication KEV: {flow['prepublication_kev']:,}\n"
            f"KEV by day 30: {flow['kev_on_or_before_landmark']:,}",
            GRAY,
        ),
        (0.57, 0.39, 0.17, f"No historical EPSS\nat landmark\nn = {flow['missing_epss']:,}", GRAY),
        (0.81, 0.39, 0.17, f"Strict day-30 cohort\nN = {flow['analysis_rows']:,}\nEvents = {flow['observed_events']:,}", GREEN),
    ]
    for x, y, width, text, color in boxes:
        patch = mpl.patches.FancyBboxPatch(
            (x, y), width, 0.34,
            boxstyle="round,pad=0.015,rounding_size=0.015",
            facecolor=mpl.colors.to_rgba(color, 0.10),
            edgecolor=color,
            linewidth=1.2,
        )
        ax.add_patch(patch)
        ax.text(x + width / 2, y + 0.17, text, ha="center", va="center", linespacing=1.30, fontsize=8.5)
    for start, end in [(0.21, 0.28), (0.50, 0.57), (0.74, 0.81)]:
        ax.annotate("", xy=(end, 0.55), xytext=(start, 0.55), arrowprops={"arrowstyle": "->", "color": GRAY})
    ax.text(
        0.5,
        0.15,
        "Prediction origin: NVD publication + 30 days  |  Event: subsequent CISA KEV inclusion  |  Censor date: 16 July 2026",
        ha="center",
        va="center",
        color="#374151",
    )
    save(fig, output_dir, "figure1_cohort_flow")


def performance_figure(
    temporal: dict,
    bootstrap: dict,
    leakage: dict,
    output_dir: Path,
) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(8.2, 6.4))
    x = np.arange(len(HORIZONS))
    split_specs = [
        ("validation_2024", "2024 validation", BLUE, "o"),
        ("test_2025", "2025 test", ORANGE, "s"),
    ]

    ax = axes[0, 0]
    for split, label, color, marker in split_specs:
        point = np.asarray([temporal[split]["dynamic_auc_percentile"][str(h)] for h in HORIZONS])
        intervals = bootstrap["temporal_validation"][split]["intervals"]
        low = np.asarray([intervals[f"dynamic_auc_{h}"]["ci95_low"] for h in HORIZONS])
        high = np.asarray([intervals[f"dynamic_auc_{h}"]["ci95_high"] for h in HORIZONS])
        ax.errorbar(
            x, point, yerr=np.vstack([point - low, high - point]),
            color=color, marker=marker, linewidth=1.6, capsize=3, label=label,
        )
    ax.axhline(0.5, color=GRAY, linewidth=1, linestyle=":")
    ax.set_xticks(x, HORIZONS)
    ax.set_ylim(0.3, 0.9)
    ax.set_xlabel("Horizon after landmark (days)")
    ax.set_ylabel("Cumulative/dynamic AUC")
    ax.set_title("Prospective discrimination")
    ax.legend(frameon=False)
    panel_label(ax, "A")

    ax = axes[0, 1]
    for split, label, color, marker in split_specs:
        historical = [leakage[split]["dynamic_auc"][str(h)]["historical_landmark"] for h in HORIZONS]
        future = [leakage[split]["dynamic_auc"][str(h)]["future_snapshot_negative_control"] for h in HORIZONS]
        ax.plot(x, historical, color=color, marker=marker, linewidth=1.6)
        ax.plot(x, future, color=color, marker=marker, linewidth=1.4, linestyle="--", markerfacecolor="white")
    ax.axhline(0.5, color=GRAY, linewidth=1, linestyle=":")
    ax.set_xticks(x, HORIZONS)
    ax.set_ylim(0.5, 1.02)
    ax.set_xlabel("Horizon after landmark (days)")
    ax.set_ylabel("Cumulative/dynamic AUC")
    ax.set_title("Future-snapshot leakage stress test")
    ax.text(1.45, 0.915, "Future snapshot (leaked): both >0.97", ha="center", va="center", fontsize=8)
    ax.text(3.08, historical[-1], "2025 historical", color=ORANGE, va="center", fontsize=8)
    historical_2024 = leakage["validation_2024"]["dynamic_auc"]["365"]["historical_landmark"]
    ax.text(3.08, historical_2024, "2024 historical", color=BLUE, va="center", fontsize=8)
    ax.set_xlim(-0.15, 3.72)
    panel_label(ax, "B")

    ax = axes[1, 0]
    for split, label, color, marker in split_specs:
        ratios = [temporal[split]["calibration"][str(h)]["observed_to_predicted_ratio"] for h in HORIZONS]
        ax.plot(x, ratios, color=color, marker=marker, linewidth=1.6, label=label)
    ax.axhline(1.0, color=GRAY, linewidth=1, linestyle=":")
    ax.set_xticks(x, HORIZONS)
    ax.set_xlabel("Horizon after landmark (days)")
    ax.set_ylabel("Observed / predicted risk")
    ax.set_title("Observed-to-predicted risk")
    ax.legend(frameon=False)
    panel_label(ax, "C")

    ax = axes[1, 1]
    versions = list(bootstrap["version_hazard_ratios"].keys())
    y = np.arange(len(versions))[::-1]
    point = np.asarray([bootstrap["version_hazard_ratios"][v]["point_hazard_ratio"] for v in versions])
    low = np.asarray([bootstrap["version_hazard_ratios"][v]["bootstrap_hazard_ratio"]["ci95_low"] for v in versions])
    high = np.asarray([bootstrap["version_hazard_ratios"][v]["bootstrap_hazard_ratio"]["ci95_high"] for v in versions])
    ax.errorbar(point, y, xerr=np.vstack([point - low, high - point]), fmt="o", color=GREEN, capsize=3)
    ax.axvline(1.0, color=GRAY, linewidth=1, linestyle=":")
    ax.set_yticks(y, versions)
    ax.set_xlim(1.0, 2.1)
    ax.set_xlabel("Hazard ratio per version-specific SD")
    ax.set_title("Raw EPSS association within model version")
    for px, py in zip(point, y):
        ax.text(px + 0.04, py, f"{px:.2f}", va="center", fontsize=8)
    panel_label(ax, "D")

    fig.tight_layout(h_pad=2.1, w_pad=1.8)
    save(fig, output_dir, "figure2_performance_leakage_calibration")


def capacity_figure(operational: dict, output_dir: Path) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(8.2, 6.3), sharex=True)
    capacities = [100, 500, 1000]
    horizons = [90, 180, 365]
    colors = [BLUE, ORANGE, GREEN]
    split_specs = [("validation_2024", "2024 validation"), ("test_2025", "2025 test")]
    for column, (split, split_label) in enumerate(split_specs):
        for row, metric in enumerate(("recall", "precision")):
            ax = axes[row, column]
            for horizon, color in zip(horizons, colors):
                item = operational["periods"][split][str(horizon)]
                values = []
                lows = []
                highs = []
                for capacity in capacities:
                    key = f"top_{capacity}_per_publication_month"
                    values.append(item["monthly_capacity"][key][metric])
                    interval = item["monthly_capacity_block_bootstrap"][key]["intervals"][metric]
                    lows.append(interval["ci95_low"])
                    highs.append(interval["ci95_high"])
                values = np.asarray(values)
                lows = np.asarray(lows)
                highs = np.asarray(highs)
                ax.errorbar(
                    capacities,
                    values,
                    yerr=np.vstack([values - lows, highs - values]),
                    color=color,
                    marker="o",
                    linewidth=1.5,
                    capsize=3,
                    label=f"{horizon} days",
                )
            ax.set_title(f"{split_label}: {'recall' if metric == 'recall' else 'precision'}")
            ax.set_ylabel("Recall" if metric == "recall" else "Precision")
            if metric == "precision":
                ax.yaxis.set_major_formatter(mpl.ticker.PercentFormatter(xmax=1.0, decimals=1))
            ax.set_xticks(capacities)
            ax.set_xlabel("Monthly review capacity (CVEs)")
            ax.legend(frameon=False)
            panel_label(ax, chr(ord("A") + row * 2 + column))
    fig.tight_layout(h_pad=2.0, w_pad=1.8)
    save(fig, output_dir, "figure3_operational_capacity")


def freshness_figure(sensitivity: dict, output_dir: Path) -> None:
    groups = ["0-7", "8-14", "15-21", "22-30"]
    split_specs = [
        ("full_2022_2025", "Full cohort", GRAY, "^"),
        ("validation_2024", "2024 validation", BLUE, "o"),
        ("test_2025", "2025 test", ORANGE, "s"),
    ]
    data = sensitivity["snapshot_freshness_sensitivity"]
    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.2))
    ax = axes[0]
    counts = [data["overall_age_distribution"]["counts"][group] for group in groups]
    ax.bar(groups, counts, color=mpl.colors.to_rgba(BLUE, 0.65), width=0.72)
    ax.set_ylabel("CVEs")
    ax.set_xlabel("Age of EPSS snapshot at landmark (days)")
    ax.set_title("Monthly-snapshot age distribution")
    ax.yaxis.set_major_formatter(mpl.ticker.StrMethodFormatter("{x:,.0f}"))
    panel_label(ax, "A")

    ax = axes[1]
    for split, label, color, marker in split_specs:
        values = [
            data["stratified_complete_followup_metrics"][split][group]["metrics"]["365"]["auroc"]
            for group in groups
        ]
        ax.plot(groups, values, color=color, marker=marker, linewidth=1.5, label=label)
    ax.axhline(0.5, color=GRAY, linestyle=":", linewidth=1)
    ax.set_ylim(0.45, 0.92)
    ax.set_ylabel("365-day complete-follow-up AUROC")
    ax.set_xlabel("Age of EPSS snapshot at landmark (days)")
    ax.set_title("Sensitivity to snapshot freshness")
    ax.legend(frameon=False)
    panel_label(ax, "B")
    fig.tight_layout(w_pad=2.0)
    save(fig, output_dir, "figure_s1_snapshot_freshness")


def monthly_weekly_figure(comparison: dict, output_dir: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.2), sharey=True)
    specs = [("monthly", "Monthly primary", BLUE, "o"), ("weekly", "Weekly sensitivity", ORANGE, "s")]
    for ax, split, title in zip(
        axes,
        ("validation_2024", "test_2025"),
        ("2024 validation", "2025 test"),
    ):
        for schedule, label, color, marker in specs:
            metrics = comparison[schedule][split]["dynamic_auc"]
            point = np.asarray([metrics[str(h)]["estimate"] for h in HORIZONS])
            low = np.asarray([metrics[str(h)]["ci95_low"] for h in HORIZONS])
            high = np.asarray([metrics[str(h)]["ci95_high"] for h in HORIZONS])
            ax.errorbar(
                np.arange(len(HORIZONS)),
                point,
                yerr=np.vstack([point - low, high - point]),
                color=color,
                marker=marker,
                linewidth=1.5,
                capsize=3,
                label=label,
            )
        ax.axhline(0.5, color=GRAY, linestyle=":", linewidth=1)
        ax.set_xticks(np.arange(len(HORIZONS)), HORIZONS)
        ax.set_ylim(0.3, 1.02)
        ax.set_xlabel("Horizon after landmark (days)")
        ax.set_title(title)
        ax.legend(frameon=False)
    axes[0].set_ylabel("Cumulative/dynamic AUC")
    panel_label(axes[0], "A")
    panel_label(axes[1], "B")
    fig.tight_layout(w_pad=2.0)
    save(fig, output_dir, "figure_s2_monthly_weekly_comparison")


def main() -> None:
    args = parse_args()
    style()
    replication = load(args.results_dir / "strict_landmark30_replication.json")
    temporal = load(args.results_dir / "temporal_validation.json")
    bootstrap = load(args.results_dir / "block_bootstrap_validation.json")
    leakage = load(args.results_dir / "temporal_leakage_audit.json")
    operational = load(args.results_dir / "operational_capacity_evaluation.json")
    sensitivity = load(args.results_dir / "sensitivity_analyses.json")
    comparison = load(args.results_dir / "monthly_weekly_comparison.json")
    cohort_flow(replication, args.output_dir)
    performance_figure(temporal, bootstrap, leakage, args.output_dir)
    capacity_figure(operational, args.output_dir)
    freshness_figure(sensitivity, args.output_dir)
    monthly_weekly_figure(comparison, args.output_dir)
    print(f"Wrote figures to {args.output_dir}")


if __name__ == "__main__":
    main()
