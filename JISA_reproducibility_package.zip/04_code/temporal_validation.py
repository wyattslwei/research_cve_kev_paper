#!/usr/bin/env python3
"""Temporal and censoring-aware evaluation for the strict landmark cohort."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter, KaplanMeierFitter
from sklearn.metrics import average_precision_score, roc_auc_score
from sksurv.linear_model import CoxPHSurvivalAnalysis
from sksurv.metrics import (
    brier_score,
    concordance_index_ipcw,
    cumulative_dynamic_auc,
    integrated_brier_score,
)
from sksurv.util import Surv


HORIZONS = np.asarray([30.0, 90.0, 180.0, 365.0])


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cohort", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=Path("05_results"))
    return parser.parse_args()


def survival_array(frame: pd.DataFrame) -> np.ndarray:
    return Surv.from_arrays(
        event=frame["event"].astype(bool).to_numpy(),
        time=frame["followup_days"].astype(float).to_numpy(),
    )


def prepare_feature(
    train: pd.DataFrame,
    frames: dict[str, pd.DataFrame],
) -> tuple[dict[str, np.ndarray], dict]:
    clipped = train["epss_percentile"].clip(1e-6, 1 - 1e-6)
    train_logit = np.log(clipped / (1 - clipped))
    mean = float(train_logit.mean())
    sd = float(train_logit.std(ddof=0))
    arrays: dict[str, np.ndarray] = {}
    for name, frame in frames.items():
        values = frame["epss_percentile"].clip(1e-6, 1 - 1e-6)
        logit = np.log(values / (1 - values))
        arrays[name] = ((logit - mean) / sd).to_numpy().reshape(-1, 1)
    return arrays, {"train_logit_percentile_mean": mean, "train_logit_percentile_sd": sd}


def fixed_binary_metrics(frame: pd.DataFrame, horizon: int) -> dict:
    labels = ((frame["event"] == 1) & (frame["followup_days"] <= horizon)).astype(int)
    complete = (
        (frame["followup_days"] >= horizon)
        | ((frame["event"] == 1) & (frame["followup_days"] <= horizon))
    )
    complete_labels = labels[complete]
    complete_scores = frame.loc[complete, "epss_percentile"]
    return {
        "naive": {
            "n": int(len(frame)),
            "events": int(labels.sum()),
            "auroc": float(roc_auc_score(labels, frame["epss_percentile"])),
            "average_precision": float(
                average_precision_score(labels, frame["epss_percentile"])
            ),
        },
        "complete_followup": {
            "n": int(complete.sum()),
            "events": int(complete_labels.sum()),
            "auroc": float(roc_auc_score(complete_labels, complete_scores)),
            "average_precision": float(
                average_precision_score(complete_labels, complete_scores)
            ),
        },
        "insufficient_followup": int((~complete).sum()),
    }


def calibration_bins(
    frame: pd.DataFrame,
    predicted_risk: np.ndarray,
    horizon: int,
    bins: int = 5,
) -> list[dict]:
    work = frame[["followup_days", "event"]].copy()
    work["predicted_risk"] = predicted_risk
    ranks = work["predicted_risk"].rank(method="first")
    work["bin"] = pd.qcut(ranks, q=bins, labels=False, duplicates="drop")
    output: list[dict] = []
    for bin_id, group in work.groupby("bin", sort=True):
        km = KaplanMeierFitter()
        km.fit(group["followup_days"], event_observed=group["event"])
        output.append(
            {
                "bin": int(bin_id) + 1,
                "n": int(len(group)),
                "events_total": int(group["event"].sum()),
                "mean_predicted_risk": float(group["predicted_risk"].mean()),
                "km_observed_risk": float(1.0 - km.predict(horizon)),
            }
        )
    return output


def calibration_slope(frame: pd.DataFrame, prognostic_index: np.ndarray) -> dict:
    fit = frame[["followup_days", "event"]].copy()
    fit["prognostic_index"] = prognostic_index
    model = CoxPHFitter()
    model.fit(
        fit,
        duration_col="followup_days",
        event_col="event",
        formula="prognostic_index",
        show_progress=False,
    )
    row = model.summary.loc["prognostic_index"]
    return {
        "slope": float(row["coef"]),
        "standard_error": float(row["se(coef)"]),
        "ci95_low": float(row["coef lower 95%"]),
        "ci95_high": float(row["coef upper 95%"]),
        "p_value": float(row["p"]),
    }


def evaluate_split(
    name: str,
    train: pd.DataFrame,
    frame: pd.DataFrame,
    y_train: np.ndarray,
    model: CoxPHSurvivalAnalysis,
    x: np.ndarray,
) -> dict:
    y = survival_array(frame)
    percentile = frame["epss_percentile"].to_numpy()
    auc, mean_auc = cumulative_dynamic_auc(y_train, y, percentile, HORIZONS)
    uno = concordance_index_ipcw(y_train, y, percentile, tau=365.0)

    survival_functions = model.predict_survival_function(x)
    predicted_survival = np.asarray(
        [[float(function(t)) for t in HORIZONS] for function in survival_functions]
    )
    _, brier = brier_score(y_train, y, predicted_survival, HORIZONS)
    integrated = integrated_brier_score(y_train, y, predicted_survival, HORIZONS)
    development_km = KaplanMeierFitter()
    development_km.fit(train["followup_days"], event_observed=train["event"])
    null_survival_curve = np.asarray(
        [float(development_km.predict(t)) for t in HORIZONS], dtype=float
    )
    null_predicted_survival = np.tile(null_survival_curve, (len(frame), 1))
    _, null_brier = brier_score(y_train, y, null_predicted_survival, HORIZONS)
    null_integrated = integrated_brier_score(
        y_train, y, null_predicted_survival, HORIZONS
    )
    prognostic_index = model.predict(x)

    metrics = {
        "split": name,
        "n": int(len(frame)),
        "events": int(frame["event"].sum()),
        "publication_years": sorted(int(x) for x in frame["publication_year"].unique()),
        "dynamic_auc_percentile": {
            str(int(t)): float(value) for t, value in zip(HORIZONS, auc)
        },
        "mean_dynamic_auc": float(mean_auc),
        "uno_c_tau365_percentile": float(uno[0]),
        "cox_percentile_brier": {
            str(int(t)): float(value) for t, value in zip(HORIZONS, brier)
        },
        "cox_percentile_integrated_brier_30_365": float(integrated),
        "development_km_null_brier": {
            str(int(t)): float(value) for t, value in zip(HORIZONS, null_brier)
        },
        "development_km_null_integrated_brier_30_365": float(null_integrated),
        "integrated_brier_relative_reduction_vs_null": float(
            (null_integrated - integrated) / null_integrated
        ),
        "cox_calibration_slope": calibration_slope(frame, prognostic_index),
        "fixed_window": {
            str(int(horizon)): fixed_binary_metrics(frame, int(horizon))
            for horizon in HORIZONS
        },
        "calibration": {},
    }
    for index, horizon in enumerate(HORIZONS.astype(int)):
        predicted_risk = 1.0 - predicted_survival[:, index]
        km = KaplanMeierFitter()
        km.fit(frame["followup_days"], event_observed=frame["event"])
        metrics["calibration"][str(horizon)] = {
            "mean_predicted_risk": float(predicted_risk.mean()),
            "km_observed_risk": float(1.0 - km.predict(horizon)),
            "observed_to_predicted_ratio": float(
                (1.0 - km.predict(horizon)) / predicted_risk.mean()
            ),
            "quintiles": calibration_bins(frame, predicted_risk, horizon),
        }
    return metrics


def version_diagnostics(frame: pd.DataFrame) -> dict:
    output: dict[str, dict] = {}
    for version, group in frame.groupby("epss_model_version", sort=True):
        output[str(version)] = {
            "n": int(len(group)),
            "events": int(group["event"].sum()),
            "epss_median": float(group["epss"].median()),
            "epss_percentile_median": float(group["epss_percentile"].median()),
            "publication_year_counts": {
                str(k): int(v)
                for k, v in group["publication_year"].value_counts().sort_index().items()
            },
        }
    return output


def markdown(payload: dict) -> str:
    lines = [
        "# Temporal validation and censoring-aware metrics",
        "",
        "Development: 2022-2023; validation: 2024; locked test: 2025.",
        "The Cox calibration model uses logit(EPSS percentile), scaled using the development period only.",
        "",
        "## Main metrics",
        "",
        "| Split | N | Events | Uno C (365d) | Mean dynamic AUC | Cox IBS | Null IBS | Relative reduction | Calibration slope |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for key in ("validation_2024", "test_2025"):
        item = payload[key]
        lines.append(
            f"| {key} | {item['n']:,} | {item['events']:,} | "
            f"{item['uno_c_tau365_percentile']:.3f} | {item['mean_dynamic_auc']:.3f} | "
            f"{item['cox_percentile_integrated_brier_30_365']:.6f} | "
            f"{item['development_km_null_integrated_brier_30_365']:.6f} | "
            f"{100 * item['integrated_brier_relative_reduction_vs_null']:.2f}% | "
            f"{item['cox_calibration_slope']['slope']:.3f} |"
        )
    lines += [
        "",
        "## Dynamic AUC by horizon",
        "",
        "| Split | 30d | 90d | 180d | 365d |",
        "|---|---:|---:|---:|---:|",
    ]
    for key in ("validation_2024", "test_2025"):
        auc = payload[key]["dynamic_auc_percentile"]
        lines.append(
            f"| {key} | {auc['30']:.3f} | {auc['90']:.3f} | {auc['180']:.3f} | {auc['365']:.3f} |"
        )
    lines += [
        "",
        "## Observed-to-predicted risk ratio",
        "",
        "| Split | Horizon | Mean predicted risk | KM observed risk | O/P ratio |",
        "|---|---:|---:|---:|---:|",
    ]
    for key in ("validation_2024", "test_2025"):
        for horizon, item in payload[key]["calibration"].items():
            lines.append(
                f"| {key} | {horizon} | {item['mean_predicted_risk']:.6f} | "
                f"{item['km_observed_risk']:.6f} | {item['observed_to_predicted_ratio']:.3f} |"
            )
    lines += [
        "",
        "## Interpretation guardrails",
        "",
        "- EPSS percentile is used for cross-version discrimination because raw score scales shift across model versions.",
        "- Brier and calibration results come from a Cox recalibration model trained only on 2022-2023.",
        "- The no-covariate Brier reference applies the 2022-2023 Kaplan-Meier survival curve as the same prediction for every validation/test CVE.",
        "- Fixed-window metrics and censoring-aware metrics answer different questions and are reported together rather than treated as interchangeable.",
        "- The 2025 365-day estimate must be interpreted with its censoring burden and later block-bootstrap uncertainty.",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    frame = pd.read_csv(args.cohort)
    if frame["epss_percentile"].isna().any():
        raise ValueError("EPSS percentile is required for temporal validation")

    train = frame.loc[frame["publication_year"].isin([2022, 2023])].copy()
    validation = frame.loc[frame["publication_year"] == 2024].copy()
    test = frame.loc[frame["publication_year"] == 2025].copy()
    frames = {"train": train, "validation": validation, "test": test}
    x, scaling = prepare_feature(train, frames)
    y_train = survival_array(train)
    model = CoxPHSurvivalAnalysis(alpha=0.0, ties="breslow", n_iter=100, tol=1e-9)
    model.fit(x["train"], y_train)

    payload = {
        "design": {
            "development_years": [2022, 2023],
            "validation_years": [2024],
            "test_years": [2025],
            "horizons_days": [int(x) for x in HORIZONS],
            "risk_score_for_discrimination": "historical EPSS percentile at exact publication+30-day landmark",
            "calibration_model": "Cox PH using development-scaled logit(EPSS percentile)",
        },
        "feature_scaling": scaling,
        "trained_cox": {
            "coefficient": float(model.coef_[0]),
            "hazard_ratio": float(math.exp(model.coef_[0])),
            "development_n": int(len(train)),
            "development_events": int(train["event"].sum()),
        },
        "model_version_diagnostics": version_diagnostics(frame),
        "validation_2024": evaluate_split(
            "validation_2024", train, validation, y_train, model, x["validation"]
        ),
        "test_2025": evaluate_split(
            "test_2025", train, test, y_train, model, x["test"]
        ),
    }

    (args.output_dir / "temporal_validation.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (args.output_dir / "temporal_validation.md").write_text(
        markdown(payload), encoding="utf-8"
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
