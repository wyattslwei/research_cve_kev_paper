#!/usr/bin/env python3
"""Build manuscript tables from frozen JSON outputs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


HORIZONS = (30, 90, 180, 365)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser.parse_args()


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def ci(estimate: float, interval: dict, digits: int = 3) -> str:
    return (
        f"{estimate:.{digits}f} "
        f"({interval['ci95_low']:.{digits}f}-{interval['ci95_high']:.{digits}f})"
    )


def main() -> None:
    args = parse_args()
    replication = load(args.results_dir / "strict_landmark30_replication.json")
    temporal = load(args.results_dir / "temporal_validation.json")
    bootstrap = load(args.results_dir / "block_bootstrap_validation.json")
    operational = load(args.results_dir / "operational_capacity_evaluation.json")
    sensitivity = load(args.results_dir / "sensitivity_analyses.json")
    comparison = load(args.results_dir / "monthly_weekly_comparison.json")
    supporting = load(args.results_dir / "supporting_diagnostics.json")

    flow = replication["flow"]
    desc = replication["full_cohort"]["description"]
    lines = [
        "# Manuscript tables",
        "",
        "## Table 1. Strict publication+30-day landmark cohort",
        "",
        "| Item | Count/value |",
        "|---|---:|",
        f"| Source CVEs published 2022-2025 | {flow['input_rows']:,} |",
        f"| Pre-publication KEV excluded | {flow['prepublication_kev']:,} |",
        f"| KEV on or before landmark excluded | {flow['kev_on_or_before_landmark']:,} |",
        f"| Missing historical EPSS excluded | {flow['missing_epss']:,} |",
        f"| Analysis cohort | {desc['n']:,} |",
        f"| Subsequent KEV inclusions | {desc['events']:,} |",
        f"| Right-censored observations | {desc['n'] - desc['events']:,} |",
        f"| EPSS snapshot age, median (P90), days | {desc['score_age_days']['median']:.0f} ({desc['score_age_days']['p90']:.0f}) |",
        "",
        "| Publication period | N | Events |",
        "|---|---:|---:|",
        f"| Development, 2022-2023 | {temporal['trained_cox']['development_n']:,} | {temporal['trained_cox']['development_events']} |",
        f"| Validation, 2024 | {temporal['validation_2024']['n']:,} | {temporal['validation_2024']['events']} |",
        f"| Held-out temporal test, 2025 | {temporal['test_2025']['n']:,} | {temporal['test_2025']['events']} |",
        "",
        "## Table 2. Temporal validation discrimination and prediction error",
        "",
        "Values in parentheses are 95% publication-month block-bootstrap percentile intervals.",
        "",
        "| Split | 30d dynamic AUC | 90d dynamic AUC | 180d dynamic AUC | 365d dynamic AUC | Uno C, 365d | IBS, 30-365d |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for split in ("validation_2024", "test_2025"):
        point = temporal[split]
        intervals = bootstrap["temporal_validation"][split]["intervals"]
        values = [
            ci(
                point["dynamic_auc_percentile"][str(h)],
                intervals[f"dynamic_auc_{h}"],
            )
            for h in HORIZONS
        ]
        values += [
            ci(point["uno_c_tau365_percentile"], intervals["uno_c_365"]),
            ci(point["cox_percentile_integrated_brier_30_365"], intervals["ibs_30_365"], 6),
        ]
        lines.append(f"| {split} | " + " | ".join(values) + " |")

    lines += [
        "",
        "## Table 3. Calibration of the development Cox model for KEV-inclusion risk",
        "",
        "| Split | Calibration slope (95% CI) | Horizon after landmark | Mean predicted risk | KM observed risk | Observed/predicted |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for split in ("validation_2024", "test_2025"):
        slope = temporal[split]["cox_calibration_slope"]["slope"]
        slope_ci = bootstrap["temporal_validation"][split]["intervals"]["calibration_slope"]
        for index, horizon in enumerate(HORIZONS):
            item = temporal[split]["calibration"][str(horizon)]
            lines.append(
                f"| {split if index == 0 else ''} | "
                f"{ci(slope, slope_ci) if index == 0 else ''} | {horizon} | "
                f"{item['mean_predicted_risk']:.6f} | {item['km_observed_risk']:.6f} | "
                f"{item['observed_to_predicted_ratio']:.2f} |"
            )

    lines += [
        "",
        "## Table 4. Selected 2025 publication-month-stratified workload scenarios",
        "",
        "| Horizon after landmark | Reviews per publication month | Captured/events | Recall (95% CI) | Precision (95% CI) | Lift | N needed to review | Median landmark-to-KEV days among captured events |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for horizon in (90, 180, 365):
        item = operational["periods"]["test_2025"][str(horizon)]
        for capacity in (100, 500, 1000):
            key = f"top_{capacity}_per_publication_month"
            point = item["monthly_capacity"][key]
            intervals = item["monthly_capacity_block_bootstrap"][key]["intervals"]
            lines.append(
                f"| {horizon} | {capacity} | {point['captured_events']}/{point['events']} | "
                f"{ci(point['recall'], intervals['recall'])} | "
                f"{ci(point['precision'], intervals['precision'], 4)} | "
                f"{point['lift_over_random']:.2f} | {point['number_needed_to_review']:.0f} | "
                f"{point['captured_event_lead_time_days']['median']:.0f} |"
            )

    lines += [
        "",
        "## Supplementary Table S1. Raw EPSS association within model version",
        "",
        "| EPSS version | N | Events | HR per version-specific SD | 95% block-bootstrap CI |",
        "|---|---:|---:|---:|---:|",
    ]
    for version, item in bootstrap["version_hazard_ratios"].items():
        interval = item["bootstrap_hazard_ratio"]
        lines.append(
            f"| {version} | {item['n']:,} | {item['events']} | "
            f"{item['point_hazard_ratio']:.3f} | {interval['ci95_low']:.3f}-{interval['ci95_high']:.3f} |"
        )

    lines += [
        "",
        "## Supplementary Table S2. Monthly primary versus weekly sensitivity",
        "",
        "| Split | Schedule | N | Events | Median score age | 30d AUC | 90d AUC | 180d AUC | 365d AUC | Uno C |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for split in ("validation_2024", "test_2025"):
        for schedule in ("monthly", "weekly"):
            item = comparison[schedule][split]
            values = [
                ci(item["dynamic_auc"][str(h)]["estimate"], item["dynamic_auc"][str(h)])
                for h in HORIZONS
            ]
            lines.append(
                f"| {split} | {schedule} | {item['n']:,} | {item['events']} | "
                f"{comparison[schedule]['cohort']['score_age_median']:.0f} | "
                + " | ".join(values)
                + f" | {ci(item['uno_c_365']['estimate'], item['uno_c_365'])} |"
            )

    timing = sensitivity["timing_policy_sensitivity"]
    lines += [
        "",
        "## Supplementary Table S3. Publication-origin timing conventions",
        "",
        "| Policy | N | Events | 30d risk | 90d risk | 180d risk | 365d risk |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for policy, item in timing["policies"].items():
        risk = item["cumulative_incidence"]
        lines.append(
            f"| {policy} | {item['n']:,} | {item['events']} | "
            f"{risk['30']:.5f} | {risk['90']:.5f} | {risk['180']:.5f} | {risk['365']:.5f} |"
        )

    lines += [
        "",
        "## Supplementary Table S4. Publication-month event distribution in annual evaluation cohorts",
        "",
        "| Month | N | All observed post-landmark events | Events by 30d | Events by 90d | Events by 180d | Events by 365d |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for year in ("2024", "2025"):
        for row in supporting["monthly_events"][year]:
            lines.append(
                f"| {row['publication_month']} | {row['n']:,} | "
                f"{row['post_landmark_events_observed_by_censor_date']} | "
                f"{row['events_by_30d']} | {row['events_by_90d']} | "
                f"{row['events_by_180d']} | {row['events_by_365d']} |"
            )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(args.output)


if __name__ == "__main__":
    main()
