#!/usr/bin/env python3
"""Diagnostics added as supporting robustness checks."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


HORIZONS = (30, 90, 180, 365)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cohort", type=Path, required=True)
    parser.add_argument("--capacity-json", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=Path("05_results"))
    return parser.parse_args()


def monthly_event_rows(frame: pd.DataFrame, year: int) -> list[dict]:
    subset = frame.loc[frame["publication_year"] == year].copy()
    subset["publication_month"] = (
        pd.to_datetime(subset["published_date"]).dt.to_period("M").astype(str)
    )
    rows: list[dict] = []
    for month, group in subset.groupby("publication_month", sort=True):
        row = {
            "publication_month": str(month),
            "n": int(len(group)),
            "post_landmark_events_observed_by_censor_date": int(group["event"].sum()),
        }
        for horizon in HORIZONS:
            row[f"events_by_{horizon}d"] = int(
                ((group["event"] == 1) & (group["followup_days"] <= horizon)).sum()
            )
            row[f"fully_observed_at_{horizon}d"] = bool(
                (
                    (group["followup_days"] >= horizon)
                    | ((group["event"] == 1) & (group["followup_days"] <= horizon))
                ).all()
            )
        rows.append(row)
    return rows


def capacity_eligibility(payload: dict) -> dict:
    output: dict[str, dict] = {}
    for period, horizons in payload["periods"].items():
        output[period] = {}
        for horizon, item in horizons.items():
            output[period][horizon] = {
                "included_months": item["included_months"],
                "excluded_partial_months": item["excluded_partial_months"],
                "n": item["n"],
                "events_by_horizon": item["events_by_horizon"],
            }
            key = "top_500_per_publication_month"
            if key in item["monthly_capacity"]:
                value = item["monthly_capacity"][key]
                intervals = item["monthly_capacity_block_bootstrap"][key]["intervals"]
                output[period][horizon]["capacity_500"] = {
                    "selected": value["selected"],
                    "captured_events": value["captured_events"],
                    "recall": value["recall"],
                    "recall_ci95": [
                        intervals["recall"]["ci95_low"],
                        intervals["recall"]["ci95_high"],
                    ],
                    "precision": value["precision"],
                    "random_selection_fraction": value["selected"] / value["n"],
                    "lift_over_random": value["lift_over_random"],
                }
    return output


def markdown(payload: dict) -> str:
    lines = [
        "# Supporting diagnostics",
        "",
        "These diagnostics were added as supporting robustness checks. They do not alter the prespecified estimand or headline performance results.",
        "",
        "## Publication-month event distribution",
        "",
        "| Month | N | All observed post-landmark events | Events by 30d | Events by 90d | Events by 180d | Events by 365d |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for year in (2024, 2025):
        for row in payload["monthly_events"][str(year)]:
            lines.append(
                f"| {row['publication_month']} | {row['n']:,} | "
                f"{row['post_landmark_events_observed_by_censor_date']} | "
                f"{row['events_by_30d']} | {row['events_by_90d']} | "
                f"{row['events_by_180d']} | {row['events_by_365d']} |"
            )
    lines += [
        "",
        "## Block structure",
        "",
        "| Period | Publication-month blocks | Total events | Zero-event months (all follow-up) | Zero-event months at 30d |",
        "|---|---:|---:|---:|---:|",
    ]
    for year in (2024, 2025):
        rows = payload["monthly_events"][str(year)]
        lines.append(
            f"| {year} | {len(rows)} | "
            f"{sum(row['post_landmark_events_observed_by_censor_date'] for row in rows)} | "
            f"{sum(row['post_landmark_events_observed_by_censor_date'] == 0 for row in rows)} | "
            f"{sum(row['events_by_30d'] == 0 for row in rows)} |"
        )
    lines += [
        "",
        "## Capacity-analysis complete-month ranges",
        "",
        "| Period | Horizon | Included months | Excluded partial months | N | Events |",
        "|---|---:|---|---|---:|---:|",
    ]
    for period, horizons in payload["capacity_eligibility"].items():
        for horizon, item in horizons.items():
            included = f"{item['included_months'][0]} to {item['included_months'][-1]}"
            excluded = ", ".join(item["excluded_partial_months"]) or "None"
            lines.append(
                f"| {period} | {horizon} | {included} | {excluded} | "
                f"{item['n']:,} | {item['events_by_horizon']} |"
            )
    lines += [
        "",
        "## Interpretation",
        "",
        "- The annual validation/test intervals resample 12 publication-month blocks; 500 Monte Carlo draws do not create additional independent calendar blocks.",
        "- Monthly event counts are reported to make sparse-event and zero-event-block structure visible.",
        "- Quarterly resampling was not added because it would reduce each annual validation period from 12 blocks to only four.",
        "- Capacity eligibility is defined at the publication-month level and never uses an individual CVE's eventual censoring status to decide whether that CVE enters the ranking set.",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    frame = pd.read_csv(args.cohort)
    capacity = json.loads(args.capacity_json.read_text(encoding="utf-8"))
    monthly = {str(year): monthly_event_rows(frame, year) for year in (2024, 2025)}
    payload = {
        "design": {
            "purpose": "supporting diagnostic; no change to prespecified estimand",
            "horizons_days": list(HORIZONS),
            "block_unit": "CVE publication month",
        },
        "monthly_events": monthly,
        "capacity_eligibility": capacity_eligibility(capacity),
    }
    (args.output_dir / "supporting_diagnostics.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (args.output_dir / "supporting_diagnostics.md").write_text(
        markdown(payload), encoding="utf-8"
    )
    print(json.dumps({"years": list(monthly), "output_dir": str(args.output_dir)}, indent=2))


if __name__ == "__main__":
    main()
