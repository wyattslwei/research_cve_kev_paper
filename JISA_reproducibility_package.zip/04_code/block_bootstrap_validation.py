#!/usr/bin/env python3
"""Publication-month block bootstrap for temporal validation and version HRs.

The temporal-validation model is trained once on 2022--2023 and then kept
locked.  Validation/test publication months are sampled with replacement so
the intervals quantify uncertainty in performance on a new calendar period.

For EPSS-version-specific hazard ratios, publication months are sampled with
replacement and a one-covariate Breslow Cox model is refitted in each sample.
The in-file Cox solver is used only to make hundreds of block refits practical;
its point estimates are checked against scikit-survival before bootstrapping.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from sksurv.linear_model import CoxPHSurvivalAnalysis
from sksurv.metrics import (
    brier_score,
    concordance_index_ipcw,
    cumulative_dynamic_auc,
    integrated_brier_score,
)
from sksurv.util import Surv


HORIZONS = np.asarray([30.0, 90.0, 180.0, 365.0])


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cohort", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=Path("05_results"))
    parser.add_argument("--replicates", type=int, default=500)
    parser.add_argument("--seed", type=int, default=20260718)
    return parser.parse_args()


def survival_array(frame: pd.DataFrame) -> np.ndarray:
    return Surv.from_arrays(
        event=frame["event"].astype(bool).to_numpy(),
        time=frame["followup_days"].astype(float).to_numpy(),
    )


def percentile_interval(values: list[float]) -> dict:
    clean = np.asarray(values, dtype=float)
    clean = clean[np.isfinite(clean)]
    if clean.size == 0:
        return {"valid_replicates": 0, "median": None, "ci95_low": None, "ci95_high": None}
    low, median, high = np.quantile(clean, [0.025, 0.5, 0.975])
    return {
        "valid_replicates": int(clean.size),
        "median": float(median),
        "ci95_low": float(low),
        "ci95_high": float(high),
    }


def publication_month(frame: pd.DataFrame) -> np.ndarray:
    return pd.to_datetime(frame["published_date"]).dt.to_period("M").astype(str).to_numpy()


def month_index_groups(frame: pd.DataFrame) -> tuple[np.ndarray, dict[str, np.ndarray]]:
    months = publication_month(frame)
    labels = np.unique(months)
    groups = {label: np.flatnonzero(months == label) for label in labels}
    return labels, groups


def sample_month_indices(
    labels: np.ndarray,
    groups: dict[str, np.ndarray],
    rng: np.random.Generator,
) -> np.ndarray:
    sampled = rng.choice(labels, size=len(labels), replace=True)
    return np.concatenate([groups[str(label)] for label in sampled])


def km_risk_at_horizon(times: np.ndarray, events: np.ndarray, horizon: float) -> float:
    order = np.argsort(times, kind="mergesort")
    times = times[order]
    events = events[order].astype(bool)
    at_risk = len(times)
    survival = 1.0
    start = 0
    while start < len(times) and times[start] <= horizon:
        end = start + 1
        while end < len(times) and times[end] == times[start]:
            end += 1
        deaths = int(events[start:end].sum())
        if deaths:
            survival *= 1.0 - deaths / at_risk
        at_risk -= end - start
        start = end
    return float(1.0 - survival)


def cox_breslow_1d(
    times: np.ndarray,
    events: np.ndarray,
    x: np.ndarray,
    weights: np.ndarray | None = None,
    initial: float = 0.0,
    max_iter: int = 200,
    tol: float = 1e-8,
) -> float:
    """Fit a one-covariate Cox model with Breslow ties and optional case weights."""
    times = np.asarray(times, dtype=float)
    events = np.asarray(events, dtype=bool)
    x = np.asarray(x, dtype=float)
    weights = np.ones(len(times), dtype=float) if weights is None else np.asarray(weights, dtype=float)
    keep = weights > 0
    times, events, x, weights = times[keep], events[keep], x[keep], weights[keep]
    order = np.argsort(-times, kind="mergesort")
    times, events, x, weights = times[order], events[order], x[order], weights[order]

    beta = float(initial)
    for _ in range(max_iter):
        eta = np.clip(beta * x, -50.0, 50.0)
        risk = weights * np.exp(eta)
        s0 = np.cumsum(risk)
        s1 = np.cumsum(risk * x)
        s2 = np.cumsum(risk * x * x)
        score = 0.0
        information = 0.0
        start = 0
        while start < len(times):
            end = start + 1
            while end < len(times) and times[end] == times[start]:
                end += 1
            event_weight = float(weights[start:end][events[start:end]].sum())
            if event_weight:
                event_x = float((weights[start:end] * events[start:end] * x[start:end]).sum())
                risk_mean = s1[end - 1] / s0[end - 1]
                risk_var = s2[end - 1] / s0[end - 1] - risk_mean * risk_mean
                score += event_x - event_weight * risk_mean
                information += event_weight * max(risk_var, 0.0)
            start = end
        if not np.isfinite(information) or information <= 1e-14:
            raise RuntimeError("Cox information matrix is singular")
        if abs(score) <= tol * max(1.0, float((weights * events).sum())):
            return float(beta)
        # Rare-event samples can yield an over-large first Newton step because
        # the local curvature at beta=0 is shallow.  A small trust region keeps
        # the update stable without changing the converged optimum.
        step = float(np.clip(score / information, -0.25, 0.25))
        beta += step
        if abs(step) < tol:
            return float(beta)
    raise RuntimeError(
        f"Cox solver did not converge: beta={beta:.12g}, "
        f"last_step={step:.12g}, score={score:.12g}, information={information:.12g}"
    )


def train_locked_model(train: pd.DataFrame, frames: dict[str, pd.DataFrame]) -> tuple:
    clipped = train["epss_percentile"].clip(1e-6, 1 - 1e-6)
    train_logit = np.log(clipped / (1 - clipped))
    mean = float(train_logit.mean())
    sd = float(train_logit.std(ddof=0))
    x: dict[str, np.ndarray] = {}
    for name, frame in frames.items():
        values = frame["epss_percentile"].clip(1e-6, 1 - 1e-6)
        logit = np.log(values / (1 - values))
        x[name] = ((logit - mean) / sd).to_numpy().reshape(-1, 1)
    y_train = survival_array(train)
    model = CoxPHSurvivalAnalysis(alpha=0.0, ties="breslow", n_iter=100, tol=1e-9)
    model.fit(x["train"], y_train)
    return model, x, y_train, {"mean": mean, "sd": sd}


def prediction_arrays(model: CoxPHSurvivalAnalysis, x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    functions = model.predict_survival_function(x)
    survival = np.asarray([[float(function(t)) for t in HORIZONS] for function in functions])
    return survival, model.predict(x)


def fixed_window_differences(frame: pd.DataFrame, indices: np.ndarray, horizon: int) -> dict:
    sample = frame.iloc[indices]
    labels = ((sample["event"] == 1) & (sample["followup_days"] <= horizon)).astype(int)
    complete = (
        (sample["followup_days"] >= horizon)
        | ((sample["event"] == 1) & (sample["followup_days"] <= horizon))
    ).to_numpy()
    if labels.nunique() < 2 or labels[complete].nunique() < 2:
        raise RuntimeError("Fixed-window sample has fewer than two outcome classes")
    from sklearn.metrics import average_precision_score, roc_auc_score

    scores = sample["epss_percentile"].to_numpy()
    naive_auc = roc_auc_score(labels, scores)
    complete_auc = roc_auc_score(labels.to_numpy()[complete], scores[complete])
    naive_ap = average_precision_score(labels, scores)
    complete_ap = average_precision_score(labels.to_numpy()[complete], scores[complete])
    return {
        "auroc_naive_minus_complete": float(naive_auc - complete_auc),
        "ap_naive_minus_complete": float(naive_ap - complete_ap),
    }


def bootstrap_temporal_split(
    frame: pd.DataFrame,
    y_train: np.ndarray,
    predicted_survival: np.ndarray,
    prognostic_index: np.ndarray,
    replicates: int,
    seed: int,
) -> dict:
    labels, groups = month_index_groups(frame)
    rng = np.random.default_rng(seed)
    collected: dict[str, list[float]] = {
        **{f"dynamic_auc_{int(t)}": [] for t in HORIZONS},
        "mean_dynamic_auc": [],
        "uno_c_365": [],
        **{f"brier_{int(t)}": [] for t in HORIZONS},
        "ibs_30_365": [],
        "calibration_slope": [],
        **{f"op_ratio_{int(t)}": [] for t in HORIZONS},
        **{f"auroc_naive_minus_complete_{int(t)}": [] for t in HORIZONS},
        **{f"ap_naive_minus_complete_{int(t)}": [] for t in HORIZONS},
    }
    failures: list[str] = []
    all_times = frame["followup_days"].to_numpy(dtype=float)
    all_events = frame["event"].to_numpy(dtype=bool)
    all_scores = frame["epss_percentile"].to_numpy(dtype=float)

    for replicate in range(replicates):
        idx = sample_month_indices(labels, groups, rng)
        sample = frame.iloc[idx]
        try:
            y = survival_array(sample)
            auc, mean_auc = cumulative_dynamic_auc(y_train, y, all_scores[idx], HORIZONS)
            uno = concordance_index_ipcw(y_train, y, all_scores[idx], tau=365.0)[0]
            _, brier = brier_score(y_train, y, predicted_survival[idx], HORIZONS)
            ibs = integrated_brier_score(y_train, y, predicted_survival[idx], HORIZONS)
            slope = cox_breslow_1d(
                all_times[idx], all_events[idx], prognostic_index[idx], initial=1.0
            )
            for horizon, value in zip(HORIZONS, auc):
                collected[f"dynamic_auc_{int(horizon)}"].append(float(value))
            collected["mean_dynamic_auc"].append(float(mean_auc))
            collected["uno_c_365"].append(float(uno))
            for horizon, value in zip(HORIZONS, brier):
                collected[f"brier_{int(horizon)}"].append(float(value))
            collected["ibs_30_365"].append(float(ibs))
            collected["calibration_slope"].append(float(slope))
            for column, horizon in enumerate(HORIZONS.astype(int)):
                observed = km_risk_at_horizon(all_times[idx], all_events[idx], float(horizon))
                predicted = float((1.0 - predicted_survival[idx, column]).mean())
                collected[f"op_ratio_{horizon}"].append(float(observed / predicted))
                difference = fixed_window_differences(frame, idx, horizon)
                collected[f"auroc_naive_minus_complete_{horizon}"].append(
                    difference["auroc_naive_minus_complete"]
                )
                collected[f"ap_naive_minus_complete_{horizon}"].append(
                    difference["ap_naive_minus_complete"]
                )
        except (ValueError, RuntimeError, FloatingPointError) as exc:
            failures.append(f"replicate {replicate}: {type(exc).__name__}: {exc}")

    return {
        "block_unit": "publication month",
        "months": [str(x) for x in labels],
        "requested_replicates": replicates,
        "complete_replicates": replicates - len(failures),
        "failed_replicates": len(failures),
        "failure_examples": failures[:10],
        "interval_method": "2.5th and 97.5th percentiles of month-block bootstrap distribution",
        "intervals": {key: percentile_interval(values) for key, values in collected.items()},
    }


def version_hr_bootstrap(
    frame: pd.DataFrame,
    replicates: int,
    seed: int,
) -> dict:
    output: dict[str, dict] = {}
    for offset, (version, group) in enumerate(frame.groupby("epss_model_version", sort=True)):
        group = group.reset_index(drop=True)
        labels, groups = month_index_groups(group)
        rng = np.random.default_rng(seed + 1000 + offset)
        raw = group["epss"].clip(1e-6, 1 - 1e-6)
        logit = np.log(raw / (1 - raw)).to_numpy()
        mean, sd = float(logit.mean()), float(logit.std(ddof=0))
        x = (logit - mean) / sd
        times = group["followup_days"].to_numpy(dtype=float)
        events = group["event"].to_numpy(dtype=bool)
        point_custom = cox_breslow_1d(times, events, x)
        y = survival_array(group)
        package = CoxPHSurvivalAnalysis(alpha=0.0, ties="breslow", n_iter=100, tol=1e-9)
        package.fit(x.reshape(-1, 1), y)
        point_package = float(package.coef_[0])
        if abs(point_custom - point_package) > 1e-6:
            raise RuntimeError(
                f"Custom/package Cox mismatch for {version}: "
                f"custom={point_custom}, package={point_package}"
            )
        estimates: list[float] = []
        failures: list[str] = []
        month_values = publication_month(group)
        for replicate in range(replicates):
            sampled = rng.choice(labels, size=len(labels), replace=True)
            counts = {str(label): 0 for label in labels}
            for label in sampled:
                counts[str(label)] += 1
            weights = np.asarray([counts[value] for value in month_values], dtype=float)
            try:
                estimates.append(cox_breslow_1d(times, events, x, weights=weights, initial=point_custom))
            except RuntimeError as exc:
                failures.append(f"replicate {replicate}: {exc}")
        beta_interval = percentile_interval(estimates)
        hr_values = [math.exp(value) for value in estimates if np.isfinite(value)]
        output[str(version)] = {
            "n": int(len(group)),
            "events": int(events.sum()),
            "months": [str(x) for x in labels],
            "estimand": "hazard ratio per one full-version-sample SD of logit(raw EPSS)",
            "scaling": {"logit_epss_mean": mean, "logit_epss_sd": sd},
            "point_beta_custom": point_custom,
            "point_beta_scikit_survival": point_package,
            "absolute_point_beta_difference": abs(point_custom - point_package),
            "point_hazard_ratio": math.exp(point_package),
            "bootstrap_beta": beta_interval,
            "bootstrap_hazard_ratio": percentile_interval(hr_values),
            "requested_replicates": replicates,
            "failed_replicates": len(failures),
            "failure_examples": failures[:10],
        }
    return output


def development_hr_bootstrap(
    train: pd.DataFrame,
    x: np.ndarray,
    replicates: int,
    seed: int,
) -> dict:
    """Block-bootstrap the development-model HR over 24 publication months."""
    values = np.asarray(x, dtype=float).reshape(-1)
    times = train["followup_days"].to_numpy(dtype=float)
    events = train["event"].to_numpy(dtype=bool)
    labels, _ = month_index_groups(train)
    month_values = publication_month(train)
    point_custom = cox_breslow_1d(times, events, values)
    package = CoxPHSurvivalAnalysis(alpha=0.0, ties="breslow", n_iter=100, tol=1e-9)
    package.fit(values.reshape(-1, 1), survival_array(train))
    point_package = float(package.coef_[0])
    if abs(point_custom - point_package) > 1e-6:
        raise RuntimeError(
            "Development custom/package Cox mismatch: "
            f"custom={point_custom}, package={point_package}"
        )
    rng = np.random.default_rng(seed + 500)
    estimates: list[float] = []
    failures: list[str] = []
    for replicate in range(replicates):
        sampled = rng.choice(labels, size=len(labels), replace=True)
        counts = {str(label): 0 for label in labels}
        for label in sampled:
            counts[str(label)] += 1
        weights = np.asarray([counts[value] for value in month_values], dtype=float)
        try:
            estimates.append(
                cox_breslow_1d(
                    times, events, values, weights=weights, initial=point_custom
                )
            )
        except RuntimeError as exc:
            failures.append(f"replicate {replicate}: {exc}")
    hr_values = [math.exp(value) for value in estimates if np.isfinite(value)]
    return {
        "n": int(len(train)),
        "events": int(events.sum()),
        "months": [str(label) for label in labels],
        "estimand": "HR per development-sample SD of logit(EPSS percentile)",
        "point_beta_custom": point_custom,
        "point_beta_scikit_survival": point_package,
        "absolute_point_beta_difference": abs(point_custom - point_package),
        "point_hazard_ratio": math.exp(point_package),
        "bootstrap_beta": percentile_interval(estimates),
        "bootstrap_hazard_ratio": percentile_interval(hr_values),
        "requested_replicates": replicates,
        "failed_replicates": len(failures),
        "failure_examples": failures[:10],
    }


def markdown(payload: dict) -> str:
    lines = [
        "# Publication-month block bootstrap",
        "",
        f"Replicates: **{payload['design']['replicates']}**; seed: **{payload['design']['seed']}**.",
        "The 2022-2023 Cox model is locked. Validation and test months are resampled as whole blocks.",
        "",
        "## Temporal validation (95% percentile intervals)",
        "",
        "| Split | Metric | Point estimate | 95% CI | Valid replicates |",
        "|---|---|---:|---:|---:|",
    ]
    point = payload["point_estimates"]
    for split in ("validation_2024", "test_2025"):
        intervals = payload["temporal_validation"][split]["intervals"]
        metrics = {
            "Uno C, 365d": (point[split]["uno_c_tau365_percentile"], intervals["uno_c_365"]),
            "Dynamic AUC, 30d": (point[split]["dynamic_auc_percentile"]["30"], intervals["dynamic_auc_30"]),
            "Dynamic AUC, 90d": (point[split]["dynamic_auc_percentile"]["90"], intervals["dynamic_auc_90"]),
            "Dynamic AUC, 180d": (point[split]["dynamic_auc_percentile"]["180"], intervals["dynamic_auc_180"]),
            "Dynamic AUC, 365d": (point[split]["dynamic_auc_percentile"]["365"], intervals["dynamic_auc_365"]),
            "IBS, 30-365d": (point[split]["cox_percentile_integrated_brier_30_365"], intervals["ibs_30_365"]),
            "Calibration slope": (point[split]["cox_calibration_slope"]["slope"], intervals["calibration_slope"]),
        }
        for label, (estimate, interval) in metrics.items():
            lines.append(
                f"| {split} | {label} | {estimate:.4f} | "
                f"{interval['ci95_low']:.4f}-{interval['ci95_high']:.4f} | "
                f"{interval['valid_replicates']} |"
            )
    lines += [
        "",
        "## Development-model hazard ratio",
        "",
        "| N | Events | Point HR | 95% month-block-bootstrap CI | Valid replicates |",
        "|---:|---:|---:|---:|---:|",
    ]
    development = payload["development_hazard_ratio"]
    development_interval = development["bootstrap_hazard_ratio"]
    lines.append(
        f"| {development['n']:,} | {development['events']} | "
        f"{development['point_hazard_ratio']:.3f} | "
        f"{development_interval['ci95_low']:.3f}-{development_interval['ci95_high']:.3f} | "
        f"{development_interval['valid_replicates']} |"
    )
    lines += [
        "",
        "## Fixed-window censoring bias",
        "",
        "Positive AUROC values mean that coding insufficient-follow-up CVEs as negatives inflates AUROC.",
        "",
        "| Split | Horizon | Point naive-complete AUROC | 95% CI | Point naive-complete AP | 95% CI |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for split in ("validation_2024", "test_2025"):
        intervals = payload["temporal_validation"][split]["intervals"]
        for horizon in (30, 90, 180, 365):
            item = point[split]["fixed_window"][str(horizon)]
            auc_point = item["naive"]["auroc"] - item["complete_followup"]["auroc"]
            ap_point = item["naive"]["average_precision"] - item["complete_followup"]["average_precision"]
            auc_ci = intervals[f"auroc_naive_minus_complete_{horizon}"]
            ap_ci = intervals[f"ap_naive_minus_complete_{horizon}"]
            lines.append(
                f"| {split} | {horizon} | {auc_point:.4f} | "
                f"{auc_ci['ci95_low']:.4f}-{auc_ci['ci95_high']:.4f} | {ap_point:.5f} | "
                f"{ap_ci['ci95_low']:.5f}-{ap_ci['ci95_high']:.5f} |"
            )
    lines += [
        "",
        "## EPSS-version-specific raw-score hazard ratios",
        "",
        "| Version | N | Events | Point HR | 95% block-bootstrap CI | Package/custom beta difference |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for version, item in payload["version_hazard_ratios"].items():
        interval = item["bootstrap_hazard_ratio"]
        lines.append(
            f"| {version} | {item['n']:,} | {item['events']} | {item['point_hazard_ratio']:.3f} | "
            f"{interval['ci95_low']:.3f}-{interval['ci95_high']:.3f} | "
            f"{item['absolute_point_beta_difference']:.2e} |"
        )
    lines += [
        "",
        "## Interpretation guardrails",
        "",
        "- Intervals are percentile block-bootstrap intervals; publication month is the resampling unit.",
        "- External-validation intervals condition on the locked development model and quantify performance variation in a new calendar period.",
        "- Raw EPSS hazard ratios are interpreted only within an EPSS model version; percentile is the cross-version ranking measure.",
        "- KEV inclusion is the event. It is not interpreted as the first real-world exploitation date.",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    frame = pd.read_csv(args.cohort)
    if frame["epss_percentile"].isna().any():
        raise ValueError("EPSS percentile is required")
    train = frame.loc[frame["publication_year"].isin([2022, 2023])].copy()
    validation = frame.loc[frame["publication_year"] == 2024].copy()
    test = frame.loc[frame["publication_year"] == 2025].copy()
    frames = {"train": train, "validation": validation, "test": test}
    model, x, y_train, scaling = train_locked_model(train, frames)
    validation_survival, validation_pi = prediction_arrays(model, x["validation"])
    test_survival, test_pi = prediction_arrays(model, x["test"])

    point_path = args.output_dir / "temporal_validation.json"
    point = json.loads(point_path.read_text(encoding="utf-8"))
    payload = {
        "design": {
            "replicates": args.replicates,
            "seed": args.seed,
            "block_unit": "publication month",
            "external_validation_model_status": "locked after fitting on 2022-2023",
            "confidence_interval": "percentile 95% interval",
        },
        "locked_model": {
            "coefficient": float(model.coef_[0]),
            "hazard_ratio": float(math.exp(model.coef_[0])),
            "scaling": scaling,
        },
        "development_hazard_ratio": development_hr_bootstrap(
            train, x["train"], args.replicates, args.seed
        ),
        "point_estimates": {
            "validation_2024": point["validation_2024"],
            "test_2025": point["test_2025"],
        },
        "temporal_validation": {
            "validation_2024": bootstrap_temporal_split(
                validation, y_train, validation_survival, validation_pi,
                args.replicates, args.seed + 10,
            ),
            "test_2025": bootstrap_temporal_split(
                test, y_train, test_survival, test_pi,
                args.replicates, args.seed + 20,
            ),
        },
        "version_hazard_ratios": version_hr_bootstrap(frame, args.replicates, args.seed),
    }
    json_path = args.output_dir / "block_bootstrap_validation.json"
    md_path = args.output_dir / "block_bootstrap_validation.md"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path.write_text(markdown(payload), encoding="utf-8")
    print(json.dumps({
        "json": str(json_path),
        "markdown": str(md_path),
        "validation_complete": payload["temporal_validation"]["validation_2024"]["complete_replicates"],
        "test_complete": payload["temporal_validation"]["test_2025"]["complete_replicates"],
    }, indent=2))


if __name__ == "__main__":
    main()
