#!/usr/bin/env python3
"""Negative-control audit using a future EPSS snapshot.

The future snapshot is intentionally invalid for prospective prediction.  It is
used only to quantify how much a retrospective score lookup can change apparent
performance relative to the historically available landmark score.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score
from sksurv.metrics import concordance_index_ipcw, cumulative_dynamic_auc
from sksurv.util import Surv


HORIZONS = np.asarray([30.0, 90.0, 180.0, 365.0])


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cohort", type=Path, required=True)
    parser.add_argument("--future-epss", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=Path("05_results"))
    return parser.parse_args()


def load_future_scores(path: Path, wanted: set[str]) -> pd.DataFrame:
    rows: list[dict] = []
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        first = handle.readline().strip()
        if first.startswith("#"):
            reader = csv.DictReader(handle)
        else:
            reader = csv.DictReader(handle, fieldnames=first.split(","))
        for row in reader:
            if row["cve"] in wanted:
                rows.append(
                    {
                        "cve_id": row["cve"],
                        "future_epss": float(row["epss"]),
                        "future_epss_percentile": float(row["percentile"]),
                    }
                )
    return pd.DataFrame(rows)


def survival_array(frame: pd.DataFrame) -> np.ndarray:
    return Surv.from_arrays(
        event=frame["event"].astype(bool).to_numpy(),
        time=frame["followup_days"].astype(float).to_numpy(),
    )


def fixed_metrics(frame: pd.DataFrame, score: str, horizon: int) -> dict:
    labels = ((frame["event"] == 1) & (frame["followup_days"] <= horizon)).astype(int)
    complete = (
        (frame["followup_days"] >= horizon)
        | ((frame["event"] == 1) & (frame["followup_days"] <= horizon))
    )
    labels = labels[complete]
    scores = frame.loc[complete, score]
    return {
        "n": int(complete.sum()),
        "events": int(labels.sum()),
        "auroc": float(roc_auc_score(labels, scores)),
        "average_precision": float(average_precision_score(labels, scores)),
    }


def evaluate_split(frame: pd.DataFrame, y_train: np.ndarray) -> dict:
    y = survival_array(frame)
    historical = frame["epss_percentile"].to_numpy()
    future = frame["future_epss_percentile"].to_numpy()
    historical_auc, historical_mean = cumulative_dynamic_auc(y_train, y, historical, HORIZONS)
    future_auc, future_mean = cumulative_dynamic_auc(y_train, y, future, HORIZONS)
    historical_uno = concordance_index_ipcw(y_train, y, historical, tau=365.0)[0]
    future_uno = concordance_index_ipcw(y_train, y, future, tau=365.0)[0]
    fixed: dict[str, dict] = {}
    for horizon in HORIZONS.astype(int):
        hist = fixed_metrics(frame, "epss_percentile", horizon)
        leaked = fixed_metrics(frame, "future_epss_percentile", horizon)
        fixed[str(horizon)] = {
            "historical_landmark": hist,
            "future_snapshot_negative_control": leaked,
            "future_minus_historical": {
                "auroc": leaked["auroc"] - hist["auroc"],
                "average_precision": leaked["average_precision"] - hist["average_precision"],
            },
        }
    return {
        "n_common": int(len(frame)),
        "events": int(frame["event"].sum()),
        "dynamic_auc": {
            str(int(t)): {
                "historical_landmark": float(old),
                "future_snapshot_negative_control": float(new),
                "future_minus_historical": float(new - old),
            }
            for t, old, new in zip(HORIZONS, historical_auc, future_auc)
        },
        "mean_dynamic_auc": {
            "historical_landmark": float(historical_mean),
            "future_snapshot_negative_control": float(future_mean),
            "future_minus_historical": float(future_mean - historical_mean),
        },
        "uno_c_365": {
            "historical_landmark": float(historical_uno),
            "future_snapshot_negative_control": float(future_uno),
            "future_minus_historical": float(future_uno - historical_uno),
        },
        "fixed_complete_followup": fixed,
    }


def raw_percentile_scale_audit(frame: pd.DataFrame) -> dict:
    output: dict[str, dict] = {}
    for horizon in (180, 365):
        labels = ((frame["event"] == 1) & (frame["followup_days"] <= horizon)).astype(int)
        complete = (
            (frame["followup_days"] >= horizon)
            | ((frame["event"] == 1) & (frame["followup_days"] <= horizon))
        )
        block: dict[str, dict] = {}
        for score in ("epss", "epss_percentile"):
            naive_auc = roc_auc_score(labels, frame[score])
            complete_auc = roc_auc_score(labels[complete], frame.loc[complete, score])
            naive_ap = average_precision_score(labels, frame[score])
            complete_ap = average_precision_score(labels[complete], frame.loc[complete, score])
            block[score] = {
                "naive_auroc": float(naive_auc),
                "complete_auroc": float(complete_auc),
                "naive_minus_complete_auroc": float(naive_auc - complete_auc),
                "naive_average_precision": float(naive_ap),
                "complete_average_precision": float(complete_ap),
                "naive_minus_complete_average_precision": float(naive_ap - complete_ap),
            }
        output[str(horizon)] = block
    return output


def markdown(payload: dict) -> str:
    lines = [
        "# Temporal leakage and score-scale audit",
        "",
        f"Future negative-control snapshot: **{payload['design']['future_snapshot']}**.",
        "The future score is deliberately invalid for prospective prediction and is never proposed as a model input.",
        "",
        "## Future-snapshot leakage stress test",
        "",
        "| Split | Metric/horizon | Historical | Future snapshot | Difference |",
        "|---|---|---:|---:|---:|",
    ]
    for split in ("validation_2024", "test_2025"):
        item = payload[split]
        for horizon, values in item["dynamic_auc"].items():
            lines.append(
                f"| {split} | Dynamic AUC {horizon}d | {values['historical_landmark']:.3f} | "
                f"{values['future_snapshot_negative_control']:.3f} | "
                f"{values['future_minus_historical']:+.3f} |"
            )
        uno = item["uno_c_365"]
        lines.append(
            f"| {split} | Uno C 365d | {uno['historical_landmark']:.3f} | "
            f"{uno['future_snapshot_negative_control']:.3f} | {uno['future_minus_historical']:+.3f} |"
        )
    lines += [
        "",
        "## Raw-score versus percentile censoring contrast (full cohort)",
        "",
        "| Horizon | Score | Naive AUROC | Complete AUROC | Difference | Naive AP | Complete AP |",
        "|---:|---|---:|---:|---:|---:|---:|",
    ]
    for horizon, item in payload["raw_percentile_scale_audit"].items():
        for score, values in item.items():
            lines.append(
                f"| {horizon} | {score} | {values['naive_auroc']:.3f} | "
                f"{values['complete_auroc']:.3f} | "
                f"{values['naive_minus_complete_auroc']:+.3f} | "
                f"{values['naive_average_precision']:.5f} | "
                f"{values['complete_average_precision']:.5f} |"
            )
    lines += [
        "",
        "## Guardrails",
        "",
        "- Any improvement from the future snapshot demonstrates retrospective information leakage, not a deployable gain.",
        "- Comparisons use the common set of CVEs present in both historical and future snapshots.",
        "- Raw EPSS is not assumed comparable across model versions; the raw/percentile contrast diagnoses scale drift interacting with censoring.",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    cohort = pd.read_csv(args.cohort)
    future = load_future_scores(args.future_epss, set(cohort["cve_id"]))
    merged = cohort.merge(future, on="cve_id", how="inner", validate="one_to_one")
    train = merged.loc[merged["publication_year"].isin([2022, 2023])].copy()
    validation = merged.loc[merged["publication_year"] == 2024].copy()
    test = merged.loc[merged["publication_year"] == 2025].copy()
    y_train = survival_array(train)
    payload = {
        "design": {
            "future_snapshot": args.future_epss.name,
            "future_snapshot_role": "deliberately leaked stress test only",
            "cohort_n": int(len(cohort)),
            "future_score_matches": int(len(merged)),
            "future_score_missing": int(len(cohort) - len(merged)),
        },
        "validation_2024": evaluate_split(validation, y_train),
        "test_2025": evaluate_split(test, y_train),
        "raw_percentile_scale_audit": raw_percentile_scale_audit(cohort),
    }
    json_path = args.output_dir / "temporal_leakage_audit.json"
    md_path = args.output_dir / "temporal_leakage_audit.md"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path.write_text(markdown(payload), encoding="utf-8")
    print(json.dumps({"json": str(json_path), "markdown": str(md_path)}, indent=2))


if __name__ == "__main__":
    main()
