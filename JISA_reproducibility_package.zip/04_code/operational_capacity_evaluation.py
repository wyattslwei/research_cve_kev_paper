#!/usr/bin/env python3
"""Operational ranking metrics under explicit monthly remediation capacities."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


HORIZONS = (30, 90, 180, 365)
TOP_FRACTIONS = (0.005, 0.01, 0.05)
MONTHLY_CAPACITIES = (100, 500, 1000)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cohort", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=Path("05_results"))
    parser.add_argument("--bootstrap-replicates", type=int, default=500)
    parser.add_argument("--seed", type=int, default=20260719)
    return parser.parse_args()


def add_fields(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    result["published_date"] = pd.to_datetime(result["published_date"])
    result["publication_month"] = result["published_date"].dt.to_period("M").astype(str)
    return result


def fully_observed_months(frame: pd.DataFrame, horizon: int) -> list[str]:
    individually_observed = (
        (frame["followup_days"] >= horizon)
        | ((frame["event"] == 1) & (frame["followup_days"] <= horizon))
    )
    status = frame.assign(complete=individually_observed).groupby("publication_month")[
        "complete"
    ].all()
    return [str(month) for month, complete in status.items() if bool(complete)]


def outcome(frame: pd.DataFrame, horizon: int) -> np.ndarray:
    return ((frame["event"] == 1) & (frame["followup_days"] <= horizon)).to_numpy(dtype=bool)


def ranking_summary(labels: np.ndarray, selected: np.ndarray) -> dict:
    total_events = int(labels.sum())
    captured = int((labels & selected).sum())
    selected_n = int(selected.sum())
    recall = captured / total_events if total_events else None
    precision = captured / selected_n if selected_n else None
    prevalence = total_events / len(labels) if len(labels) else None
    return {
        "n": int(len(labels)),
        "events": total_events,
        "selected": selected_n,
        "captured_events": captured,
        "recall": recall,
        "precision": precision,
        "number_needed_to_review": (selected_n / captured) if captured else None,
        "lift_over_random": (precision / prevalence) if precision is not None and prevalence else None,
    }


def top_fraction_metrics(frame: pd.DataFrame, horizon: int) -> dict:
    labels = outcome(frame, horizon)
    scores = frame["epss_percentile"].to_numpy()
    order = np.argsort(-scores, kind="mergesort")
    output: dict[str, dict] = {}
    for fraction in TOP_FRACTIONS:
        count = max(1, int(np.ceil(len(frame) * fraction)))
        selected = np.zeros(len(frame), dtype=bool)
        selected[order[:count]] = True
        output[f"top_{100 * fraction:g}_percent"] = ranking_summary(labels, selected)
    return output


def monthly_capacity_metrics(frame: pd.DataFrame, horizon: int) -> dict:
    labels = outcome(frame, horizon)
    output: dict[str, dict] = {}
    for capacity in MONTHLY_CAPACITIES:
        selected = np.zeros(len(frame), dtype=bool)
        for _, positions in frame.groupby("publication_month", sort=True).indices.items():
            positions = np.asarray(positions, dtype=int)
            scores = frame.iloc[positions]["epss_percentile"].to_numpy()
            order = positions[np.argsort(-scores, kind="mergesort")]
            selected[order[: min(capacity, len(order))]] = True
        summary = ranking_summary(labels, selected)
        event_times = frame.loc[selected & labels, "followup_days"].to_numpy(dtype=float)
        summary["captured_event_lead_time_days"] = {
            "median": float(np.median(event_times)) if len(event_times) else None,
            "p25": float(np.quantile(event_times, 0.25)) if len(event_times) else None,
            "p75": float(np.quantile(event_times, 0.75)) if len(event_times) else None,
        }
        output[f"top_{capacity}_per_publication_month"] = summary
    return output


def percentile_interval(values: list[float]) -> dict:
    array = np.asarray(values, dtype=float)
    array = array[np.isfinite(array)]
    if len(array) == 0:
        return {"valid_replicates": 0, "ci95_low": None, "median": None, "ci95_high": None}
    low, median, high = np.quantile(array, [0.025, 0.5, 0.975])
    return {
        "valid_replicates": int(len(array)),
        "ci95_low": float(low),
        "median": float(median),
        "ci95_high": float(high),
    }


def bootstrap_monthly_capacity(
    frame: pd.DataFrame,
    horizon: int,
    replicates: int,
    seed: int,
) -> dict:
    labels = outcome(frame, horizon)
    months = sorted(str(x) for x in frame["publication_month"].unique())
    rng = np.random.default_rng(seed)
    output: dict[str, dict] = {}
    for capacity in MONTHLY_CAPACITIES:
        month_data: dict[str, dict] = {}
        for month, positions in frame.groupby("publication_month", sort=True).indices.items():
            positions = np.asarray(positions, dtype=int)
            scores = frame.iloc[positions]["epss_percentile"].to_numpy()
            order = positions[np.argsort(-scores, kind="mergesort")]
            selected = order[: min(capacity, len(order))]
            selected_events = labels[selected]
            month_data[str(month)] = {
                "n": int(len(positions)),
                "events": int(labels[positions].sum()),
                "selected": int(len(selected)),
                "captured": int(selected_events.sum()),
                "lead_times": frame.iloc[selected]["followup_days"].to_numpy(dtype=float)[selected_events],
            }
        collected = {
            "recall": [],
            "precision": [],
            "lift_over_random": [],
            "number_needed_to_review": [],
            "median_lead_time_days": [],
        }
        for _ in range(replicates):
            sampled = rng.choice(months, size=len(months), replace=True)
            n = sum(month_data[month]["n"] for month in sampled)
            events = sum(month_data[month]["events"] for month in sampled)
            selected = sum(month_data[month]["selected"] for month in sampled)
            captured = sum(month_data[month]["captured"] for month in sampled)
            if events > 0:
                collected["recall"].append(captured / events)
            if selected > 0:
                precision = captured / selected
                collected["precision"].append(precision)
                prevalence = events / n if n else np.nan
                if prevalence > 0:
                    collected["lift_over_random"].append(precision / prevalence)
            if captured > 0:
                collected["number_needed_to_review"].append(selected / captured)
                lead = np.concatenate(
                    [month_data[month]["lead_times"] for month in sampled]
                )
                if len(lead):
                    collected["median_lead_time_days"].append(float(np.median(lead)))
        output[f"top_{capacity}_per_publication_month"] = {
            "requested_replicates": replicates,
            "block_unit": "publication month",
            "interval_method": "2.5th and 97.5th percentiles",
            "intervals": {
                metric: percentile_interval(values) for metric, values in collected.items()
            },
        }
    return output


def evaluate_period(
    frame: pd.DataFrame,
    years: list[int],
    bootstrap_replicates: int,
    seed: int,
) -> dict:
    period = frame.loc[frame["publication_year"].isin(years)].copy()
    output: dict[str, dict] = {}
    for horizon in HORIZONS:
        complete_months = fully_observed_months(period, horizon)
        eligible = period.loc[period["publication_month"].isin(complete_months)].copy()
        eligible = eligible.sort_values(["publication_month", "cve_id"]).reset_index(drop=True)
        output[str(horizon)] = {
            "eligibility_rule": "include only publication months in which every CVE has at least the horizon of follow-up",
            "included_months": complete_months,
            "excluded_partial_months": sorted(
                set(period["publication_month"].unique()) - set(complete_months)
            ),
            "n": int(len(eligible)),
            "events_by_horizon": int(outcome(eligible, horizon).sum()),
            "top_fraction": top_fraction_metrics(eligible, horizon),
            "monthly_capacity": monthly_capacity_metrics(eligible, horizon),
            "monthly_capacity_block_bootstrap": bootstrap_monthly_capacity(
                eligible,
                horizon,
                bootstrap_replicates,
                seed + horizon,
            ),
        }
    return output


def markdown(payload: dict) -> str:
    lines = [
        "# Operational capacity evaluation",
        "",
        "Ranking uses the historical EPSS percentile available at the publication+30-day landmark.",
        "Each horizon includes only complete publication months, preventing knowledge of individual censoring status from entering the queue.",
        "",
        "## Top-fraction recall",
        "",
        "| Period | Horizon | Eligible N | Events | Top 0.5% recall | Top 1% recall | Top 5% recall |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for period, horizons in payload["periods"].items():
        for horizon, item in horizons.items():
            values = item["top_fraction"]
            lines.append(
                f"| {period} | {horizon} | {item['n']:,} | {item['events_by_horizon']} | "
                f"{values['top_0.5_percent']['recall']:.3f} | "
                f"{values['top_1_percent']['recall']:.3f} | "
                f"{values['top_5_percent']['recall']:.3f} |"
            )
    lines += [
        "",
        "## Monthly remediation capacity",
        "",
        "| Period | Horizon | Capacity/month | Captured/Events | Recall (95% CI) | Precision (95% CI) | Lift | Median lead days |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for period, horizons in payload["periods"].items():
        for horizon, item in horizons.items():
            for capacity in MONTHLY_CAPACITIES:
                value = item["monthly_capacity"][f"top_{capacity}_per_publication_month"]
                boot = item["monthly_capacity_block_bootstrap"][
                    f"top_{capacity}_per_publication_month"
                ]["intervals"]
                lead = value["captured_event_lead_time_days"]["median"]
                lines.append(
                    f"| {period} | {horizon} | {capacity} | "
                    f"{value['captured_events']}/{value['events']} | {value['recall']:.3f} "
                    f"({boot['recall']['ci95_low']:.3f}-{boot['recall']['ci95_high']:.3f}) | "
                    f"{value['precision']:.5f} "
                    f"({boot['precision']['ci95_low']:.5f}-{boot['precision']['ci95_high']:.5f}) | "
                    f"{value['lift_over_random']:.1f} | "
                    f"{lead:.0f} |"
                )
    lines += [
        "",
        "## Guardrails",
        "",
        "- Capacity is defined per CVE publication month, not as a claim about a specific organization's patch workflow.",
        "- Lead time is days from the fixed 30-day landmark to later KEV inclusion for captured events; it is not time to first exploitation.",
        "- Precision is expected to be numerically low because later KEV inclusion is rare; recall, workload, lift, and number needed to review must be read together.",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    frame = add_fields(pd.read_csv(args.cohort))
    payload = {
        "design": {
            "landmark": "publication + 30 days",
            "score": "historical EPSS percentile at landmark",
            "horizons_days": list(HORIZONS),
            "top_fractions": list(TOP_FRACTIONS),
            "monthly_capacities": list(MONTHLY_CAPACITIES),
            "bootstrap_replicates": args.bootstrap_replicates,
            "bootstrap_seed": args.seed,
        },
        "periods": {
            "validation_2024": evaluate_period(
                frame, [2024], args.bootstrap_replicates, args.seed + 1000
            ),
            "test_2025": evaluate_period(
                frame, [2025], args.bootstrap_replicates, args.seed + 2000
            ),
        },
    }
    json_path = args.output_dir / "operational_capacity_evaluation.json"
    md_path = args.output_dir / "operational_capacity_evaluation.md"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path.write_text(markdown(payload), encoding="utf-8")
    print(json.dumps({"json": str(json_path), "markdown": str(md_path)}, indent=2))


if __name__ == "__main__":
    main()
