#!/usr/bin/env python3
"""Compare locked monthly primary analysis with prespecified weekly sensitivity."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


HORIZONS = (30, 90, 180, 365)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--monthly-results", type=Path, required=True)
    parser.add_argument("--weekly-results", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def analysis_block(directory: Path) -> dict:
    replication = load(directory / "strict_landmark30_replication.json")
    temporal = load(directory / "temporal_validation.json")
    bootstrap = load(directory / "block_bootstrap_validation.json")
    return {"replication": replication, "temporal": temporal, "bootstrap": bootstrap}


def split_metrics(block: dict, split: str) -> dict:
    point = block["temporal"][split]
    intervals = block["bootstrap"]["temporal_validation"][split]["intervals"]
    return {
        "n": point["n"],
        "events": point["events"],
        "dynamic_auc": {
            str(horizon): {
                "estimate": point["dynamic_auc_percentile"][str(horizon)],
                "ci95_low": intervals[f"dynamic_auc_{horizon}"]["ci95_low"],
                "ci95_high": intervals[f"dynamic_auc_{horizon}"]["ci95_high"],
            }
            for horizon in HORIZONS
        },
        "uno_c_365": {
            "estimate": point["uno_c_tau365_percentile"],
            "ci95_low": intervals["uno_c_365"]["ci95_low"],
            "ci95_high": intervals["uno_c_365"]["ci95_high"],
        },
        "ibs_30_365": {
            "estimate": point["cox_percentile_integrated_brier_30_365"],
            "ci95_low": intervals["ibs_30_365"]["ci95_low"],
            "ci95_high": intervals["ibs_30_365"]["ci95_high"],
        },
    }


def markdown(payload: dict) -> str:
    lines = [
        "# Monthly-primary versus weekly-snapshot sensitivity",
        "",
        "The monthly analysis remains the locked primary result. The Monday series is a prespecified freshness sensitivity and does not replace it.",
        "",
        "## Cohort and score freshness",
        "",
        "| Schedule | N | Events | Missing landmark EPSS | Median score age | P90 score age |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for schedule in ("monthly", "weekly"):
        item = payload[schedule]["cohort"]
        lines.append(
            f"| {schedule} | {item['n']:,} | {item['events']} | {item['missing_epss']:,} | "
            f"{item['score_age_median']:.0f} | {item['score_age_p90']:.0f} |"
        )
    lines += [
        "",
        "## Censoring-aware discrimination",
        "",
        "| Split | Schedule | 30d AUC (95% CI) | 90d AUC (95% CI) | 180d AUC (95% CI) | 365d AUC (95% CI) | Uno C 365d (95% CI) |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for split in ("validation_2024", "test_2025"):
        for schedule in ("monthly", "weekly"):
            item = payload[schedule][split]
            auc_values = []
            for horizon in HORIZONS:
                metric = item["dynamic_auc"][str(horizon)]
                auc_values.append(
                    f"{metric['estimate']:.3f} ({metric['ci95_low']:.3f}-{metric['ci95_high']:.3f})"
                )
            uno = item["uno_c_365"]
            lines.append(
                f"| {split} | {schedule} | {' | '.join(auc_values)} | "
                f"{uno['estimate']:.3f} ({uno['ci95_low']:.3f}-{uno['ci95_high']:.3f}) |"
            )
    lines += [
        "",
        "## Interpretation",
        "",
        "- Weekly snapshots reduce measurement delay and missingness; higher short-horizon AUC is therefore consistent with a freshness-sensitive signal.",
        "- The weekly analysis uses the same landmark, event, censor date, temporal split, and metrics as the monthly primary analysis.",
        "- Overlapping confidence intervals and the post-feasibility timing of this comparison preclude a claim that weekly is definitively superior at every horizon.",
        "- The sensitivity supports reporting archive cadence as a design parameter rather than treating any historical EPSS lookup as equivalent.",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    blocks = {
        "monthly": analysis_block(args.monthly_results),
        "weekly": analysis_block(args.weekly_results),
    }
    payload: dict[str, dict] = {
        "design": {
            "monthly_status": "locked primary",
            "weekly_status": "prespecified snapshot-freshness sensitivity",
            "horizons_days": list(HORIZONS),
        }
    }
    for schedule, block in blocks.items():
        description = block["replication"]["full_cohort"]["description"]
        payload[schedule] = {
            "cohort": {
                "n": description["n"],
                "events": description["events"],
                "missing_epss": block["replication"]["flow"]["missing_epss"],
                "score_age_median": description["score_age_days"]["median"],
                "score_age_p90": description["score_age_days"]["p90"],
                "score_age_max": description["score_age_days"]["max"],
            },
            "validation_2024": split_metrics(block, "validation_2024"),
            "test_2025": split_metrics(block, "test_2025"),
        }
    json_path = args.output_dir / "monthly_weekly_comparison.json"
    md_path = args.output_dir / "monthly_weekly_comparison.md"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path.write_text(markdown(payload), encoding="utf-8")
    print(json.dumps({"json": str(json_path), "markdown": str(md_path)}, indent=2))


if __name__ == "__main__":
    main()
