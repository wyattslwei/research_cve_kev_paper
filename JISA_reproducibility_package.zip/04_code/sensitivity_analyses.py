#!/usr/bin/env python3
"""Timing-policy and EPSS snapshot-freshness sensitivity analyses."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter, KaplanMeierFitter
from sklearn.metrics import average_precision_score, roc_auc_score


HORIZONS = (30, 90, 180, 365)
AGE_BINS = [-1, 7, 14, 21, 30]
AGE_LABELS = ["0-7", "8-14", "15-21", "22-30"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--event-cohort", type=Path, required=True)
    parser.add_argument("--landmark-cohort", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=Path("05_results"))
    parser.add_argument("--censor-date", default="2026-07-16")
    return parser.parse_args()


def km_policy(frame: pd.DataFrame, policy: str, censor_date: pd.Timestamp) -> dict:
    work = frame.copy()
    delay = (work["kev_date"] - work["published_date"]).dt.days
    prepublication = work["kev_date"].notna() & (delay < 0)
    same_day = work["kev_date"].notna() & (delay == 0)

    if policy == "exclude_prepublication_day1_same_day":
        work = work.loc[~prepublication].copy()
    elif policy == "exclude_prepublication_and_same_day":
        work = work.loc[~(prepublication | same_day)].copy()
    elif policy == "include_all_kev_at_day1_nonincident_diagnostic":
        pass
    else:
        raise ValueError(policy)

    observed = work["kev_date"].notna()
    raw_time = np.where(
        observed,
        (work["kev_date"] - work["published_date"]).dt.days,
        (censor_date - work["published_date"]).dt.days,
    )
    time = np.maximum(1, np.asarray(raw_time, dtype=int))
    km = KaplanMeierFitter().fit(time, event_observed=observed.astype(int))
    return {
        "n": int(len(work)),
        "events": int(observed.sum()),
        "cumulative_incidence": {
            str(horizon): float(1.0 - km.predict(horizon)) for horizon in HORIZONS
        },
    }


def timing_policy_sensitivity(path: Path, censor_date: pd.Timestamp) -> dict:
    frame = pd.read_csv(path, usecols=["cve_id", "published_date", "kev_date_added"])
    frame["published_date"] = pd.to_datetime(frame["published_date"])
    frame["kev_date"] = pd.to_datetime(frame["kev_date_added"], errors="coerce")
    delay = (frame["kev_date"] - frame["published_date"]).dt.days
    prepublication = frame["kev_date"].notna() & (delay < 0)
    same_day = frame["kev_date"].notna() & (delay == 0)
    on_or_before_day30 = frame["kev_date"].notna() & (delay <= 30)
    policies = [
        "exclude_prepublication_day1_same_day",
        "exclude_prepublication_and_same_day",
        "include_all_kev_at_day1_nonincident_diagnostic",
    ]
    return {
        "counts": {
            "input_n": int(len(frame)),
            "kev_events": int(frame["kev_date"].notna().sum()),
            "prepublication_kev": int(prepublication.sum()),
            "same_day_kev": int(same_day.sum()),
            "kev_on_or_before_publication_plus_30_days": int(on_or_before_day30.sum()),
        },
        "policies": {
            policy: km_policy(frame, policy, censor_date) for policy in policies
        },
        "landmark_invariance": (
            "All KEV inclusions on or before publication+30 days are excluded from the "
            "primary risk set. Therefore day-0 versus day-1 coding changes the descriptive "
            "publication-origin curve but not the strict day-30 landmark cohort."
        ),
    }


def fixed_complete_metrics(frame: pd.DataFrame, horizon: int) -> dict:
    complete = (
        (frame["followup_days"] >= horizon)
        | ((frame["event"] == 1) & (frame["followup_days"] <= horizon))
    )
    labels = (
        (frame.loc[complete, "event"] == 1)
        & (frame.loc[complete, "followup_days"] <= horizon)
    ).astype(int)
    scores = frame.loc[complete, "epss_percentile"]
    if labels.nunique() < 2:
        return {
            "n": int(complete.sum()),
            "events": int(labels.sum()),
            "auroc": None,
            "average_precision": None,
        }
    return {
        "n": int(complete.sum()),
        "events": int(labels.sum()),
        "auroc": float(roc_auc_score(labels, scores)),
        "average_precision": float(average_precision_score(labels, scores)),
    }


def freshness_sensitivity(path: Path) -> dict:
    frame = pd.read_csv(path)
    frame["age_group"] = pd.cut(
        frame["score_age_days"], bins=AGE_BINS, labels=AGE_LABELS
    ).astype(str)

    group_results: dict[str, dict] = {}
    for split_name, years in {
        "full_2022_2025": [2022, 2023, 2024, 2025],
        "validation_2024": [2024],
        "test_2025": [2025],
    }.items():
        split = frame.loc[frame["publication_year"].isin(years)].copy()
        group_results[split_name] = {}
        for label in AGE_LABELS:
            group = split.loc[split["age_group"] == label].copy()
            group_results[split_name][label] = {
                "n": int(len(group)),
                "events_total": int(group["event"].sum()),
                "score_age_median": float(group["score_age_days"].median()),
                "metrics": {
                    str(horizon): fixed_complete_metrics(group, horizon)
                    for horizon in HORIZONS
                },
            }

    clipped = frame["epss_percentile"].clip(1e-6, 1 - 1e-6)
    logit = np.log(clipped / (1 - clipped))
    frame["z_logit_percentile"] = (logit - logit.mean()) / logit.std(ddof=0)
    frame["age_per_30_days"] = frame["score_age_days"] / 30.0
    frame["score_by_age"] = frame["z_logit_percentile"] * frame["age_per_30_days"]
    fit = frame[
        [
            "followup_days",
            "event",
            "z_logit_percentile",
            "age_per_30_days",
            "score_by_age",
            "epss_model_version",
        ]
    ].copy()
    cph = CoxPHFitter()
    cph.fit(
        fit,
        duration_col="followup_days",
        event_col="event",
        strata=["epss_model_version"],
        formula="z_logit_percentile + age_per_30_days + score_by_age",
        show_progress=False,
    )
    coefficients: dict[str, dict] = {}
    for term in ("z_logit_percentile", "age_per_30_days", "score_by_age"):
        row = cph.summary.loc[term]
        coefficients[term] = {
            "coefficient": float(row["coef"]),
            "hazard_ratio": float(row["exp(coef)"]),
            "ci95_low": float(row["exp(coef) lower 95%"]),
            "ci95_high": float(row["exp(coef) upper 95%"]),
            "p_value": float(row["p"]),
        }
    return {
        "overall_age_distribution": {
            "min": int(frame["score_age_days"].min()),
            "median": float(frame["score_age_days"].median()),
            "p90": float(frame["score_age_days"].quantile(0.9)),
            "max": int(frame["score_age_days"].max()),
            "counts": {
                label: int((frame["age_group"] == label).sum()) for label in AGE_LABELS
            },
        },
        "stratified_complete_followup_metrics": group_results,
        "version_stratified_cox_interaction": {
            "model": (
                "Cox PH stratified by EPSS model version; global standardized "
                "logit(percentile), score age/30, and their interaction"
            ),
            "n": int(len(frame)),
            "events": int(frame["event"].sum()),
            "coefficients": coefficients,
            "interpretation": (
                "The interaction tests whether the score association changes as the monthly "
                "snapshot becomes older. It is a sensitivity analysis, not a causal effect of age."
            ),
        },
    }


def fmt(value: float | None, digits: int = 3) -> str:
    return "NA" if value is None else f"{value:.{digits}f}"


def markdown(payload: dict) -> str:
    timing = payload["timing_policy_sensitivity"]
    freshness = payload["snapshot_freshness_sensitivity"]
    lines = [
        "# Timing-policy and snapshot-freshness sensitivity analyses",
        "",
        "## Publication-origin event-time policies",
        "",
        f"Pre-publication KEV records: **{timing['counts']['prepublication_kev']}**; "
        f"same-day records: **{timing['counts']['same_day_kev']}**.",
        "",
        "| Policy | N | Events | 30d risk | 90d risk | 180d risk | 365d risk |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for policy, item in timing["policies"].items():
        risk = item["cumulative_incidence"]
        lines.append(
            f"| {policy} | {item['n']:,} | {item['events']} | {risk['30']:.5f} | "
            f"{risk['90']:.5f} | {risk['180']:.5f} | {risk['365']:.5f} |"
        )
    lines += [
        "",
        timing["landmark_invariance"],
        "",
        "## EPSS snapshot age",
        "",
        f"Snapshot age: median **{freshness['overall_age_distribution']['median']:.0f}** days; "
        f"90th percentile **{freshness['overall_age_distribution']['p90']:.0f}** days; "
        f"range **{freshness['overall_age_distribution']['min']}-"
        f"{freshness['overall_age_distribution']['max']}** days.",
        "",
        "### Complete-follow-up AUROC by age group",
        "",
        "| Split | Age days | N | Events total | 90d AUROC | 180d AUROC | 365d AUROC |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for split, groups in freshness["stratified_complete_followup_metrics"].items():
        for label, item in groups.items():
            metrics = item["metrics"]
            lines.append(
                f"| {split} | {label} | {item['n']:,} | {item['events_total']} | "
                f"{fmt(metrics['90']['auroc'])} | {fmt(metrics['180']['auroc'])} | "
                f"{fmt(metrics['365']['auroc'])} |"
            )
    interaction = freshness["version_stratified_cox_interaction"]
    lines += [
        "",
        "### Version-stratified Cox interaction",
        "",
        "| Term | HR | 95% CI | p |",
        "|---|---:|---:|---:|",
    ]
    for term, item in interaction["coefficients"].items():
        lines.append(
            f"| {term} | {item['hazard_ratio']:.3f} | "
            f"{item['ci95_low']:.3f}-{item['ci95_high']:.3f} | {item['p_value']:.3g} |"
        )
    lines += [
        "",
        "## Guardrails",
        "",
        "- The nonincident policy that moves pre-publication events to day 1 is diagnostic only and is not used in the primary analysis.",
        "- Same-day coding cannot affect the day-30 landmark cohort because all events on or before the landmark are excluded.",
        "- Snapshot age is determined by the monthly archive schedule and publication timing; its interaction is not causal.",
        "- Age-stratified AUROCs are sparse descriptive sensitivity results and are not used to choose a favorable subgroup.",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "design": {
            "administrative_censor_date": args.censor_date,
            "horizons_days": list(HORIZONS),
            "snapshot_age_groups_days": AGE_LABELS,
        },
        "timing_policy_sensitivity": timing_policy_sensitivity(
            args.event_cohort, pd.Timestamp(args.censor_date)
        ),
        "snapshot_freshness_sensitivity": freshness_sensitivity(args.landmark_cohort),
    }
    json_path = args.output_dir / "sensitivity_analyses.json"
    md_path = args.output_dir / "sensitivity_analyses.md"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path.write_text(markdown(payload), encoding="utf-8")
    print(json.dumps({"json": str(json_path), "markdown": str(md_path)}, indent=2))


if __name__ == "__main__":
    main()
