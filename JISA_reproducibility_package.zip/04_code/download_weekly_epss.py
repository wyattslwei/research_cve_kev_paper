#!/usr/bin/env python3
"""Download and validate a deterministic Monday series of historical EPSS snapshots."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import time
import urllib.error
import urllib.request
from datetime import date, timedelta
from pathlib import Path


BASE_URL = "https://epss.cyentia.com"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--start", type=date.fromisoformat, default=date(2022, 1, 3))
    parser.add_argument("--end", type=date.fromisoformat, default=date(2026, 7, 13))
    parser.add_argument("--retries", type=int, default=3)
    return parser.parse_args()


def weekly_dates(start: date, end: date) -> list[date]:
    if start.weekday() != 0:
        start += timedelta(days=(7 - start.weekday()) % 7)
    dates: list[date] = []
    current = start
    while current <= end:
        dates.append(current)
        current += timedelta(days=7)
    return dates


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate(path: Path) -> dict:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        first = handle.readline().strip()
        second = handle.readline().strip()
    header = second if first.startswith("#") else first
    if "cve" not in header or "epss" not in header:
        raise ValueError(f"Unexpected EPSS header in {path}: {header!r}")
    return {
        "size_bytes": path.stat().st_size,
        "sha256": sha256(path),
        "metadata": first if first.startswith("#") else None,
        "header": header,
    }


def download(url: str, destination: Path, retries: int) -> None:
    temporary = destination.with_suffix(destination.suffix + ".part")
    request = urllib.request.Request(url, headers={"User-Agent": "cve-kev-research/1.0"})
    last_error: Exception | None = None
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                with temporary.open("wb") as handle:
                    while True:
                        chunk = response.read(1024 * 1024)
                        if not chunk:
                            break
                        handle.write(chunk)
            temporary.replace(destination)
            return
        except (OSError, urllib.error.URLError, urllib.error.HTTPError) as exc:
            last_error = exc
            if temporary.exists():
                temporary.unlink()
            time.sleep(2 ** attempt)
    raise RuntimeError(f"Failed to download {url}: {last_error}")


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    manifest: dict[str, dict] = {}
    for index, snapshot_date in enumerate(weekly_dates(args.start, args.end), start=1):
        filename = f"epss_scores-{snapshot_date.isoformat()}.csv.gz"
        destination = args.output_dir / filename
        url = f"{BASE_URL}/{filename}"
        if not destination.exists():
            download(url, destination, args.retries)
        manifest[snapshot_date.isoformat()] = {"url": url, **validate(destination)}
        if index % 20 == 0:
            print(f"validated {index} weekly snapshots", flush=True)
    output = {
        "schedule": "Every Monday, inclusive",
        "start": args.start.isoformat(),
        "end": args.end.isoformat(),
        "snapshot_count": len(manifest),
        "total_size_bytes": sum(item["size_bytes"] for item in manifest.values()),
        "snapshots": manifest,
    }
    manifest_path = args.output_dir / "weekly_epss_manifest.json"
    manifest_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "manifest": str(manifest_path),
        "snapshot_count": output["snapshot_count"],
        "total_size_bytes": output["total_size_bytes"],
    }, indent=2))


if __name__ == "__main__":
    main()
