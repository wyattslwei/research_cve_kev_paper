#!/usr/bin/env python3
"""Rebuild the publication+30-day landmark cohort and replicate survival results.

The prediction origin is the exact landmark date.  The predictor is the latest
historical EPSS snapshot available on or before that date.  CVEs already in KEV
by the landmark are excluded from the risk set, and events after the frozen
administrative censor date are not treated as observed.
"""

from __future__ import annotations

import argparse
import bisect
import csv
import gzip
import json
import math
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
from lifelines import CoxPHFitter, KaplanMeierFitter
from lifelines.exceptions import ConvergenceError
from lifelines.statistics import proportional_hazard_test
from sklearn.metrics import average_precision_score, roc_auc_score
from sksurv.linear_model import CoxPHSurvivalAnalysis
from sksurv.util import Surv


HORIZONS = (30, 90, 180, 365)
V3_MODEL_VERSION = "v2023.03.01"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--cohort",
        type=Path,
        required=True,
        help="Processed NVD-KEV cohort CSV.",
    )
    parser.add_argument(
        "--epss-dir",
        type=Path,
        required=True,
        help="Directory containing historical epss_scores-YYYY-MM-DD.csv.gz files.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("05_results"),
    )
    parser.add_argument(
        "--processed-dir",
        type=Path,
        default=Path("03_data/processed"),
    )
    parser.add_argument("--landmark-days", type=int, default=30)
    parser.add_argument("--censor-date", type=date.fromisoformat, default=date(2026, 7, 16))
    return parser.parse_args()


def load_cohort(path: Path) -> list[dict]:
    rows: list[dict] = []
    with path.open(encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            rows.append(
                {
                    "cve_id": row["cve_id"],
                    "published_date": date.fromisoformat(row["published_date"]),
                    "kev_date_added": (
                        date.fromisoformat(row["kev_date_added"])
                        if row["kev_date_added"]
                        else None
                    ),
                }
            )
    return rows


def snapshot_date(path: Path) -> date:
    value = path.name.removeprefix("epss_scores-").removesuffix(".csv.gz")
    return date.fromisoformat(value)


def snapshot_metadata(path: Path) -> dict[str, str]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        first = handle.readline().strip()
    if not first.startswith("#"):
        return {"model_version": "unknown"}
    values: dict[str, str] = {}
    for item in first[1:].split(","):
        key, _, value = item.partition(":")
        values[key] = value
    return values


def load_selected_scores(path: Path, wanted: set[str]) -> dict[str, tuple[float, float | None]]:
    found: dict[str, tuple[float, float | None]] = {}
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        first = handle.readline().strip()
        if first.startswith("#"):
            reader = csv.DictReader(handle)
        else:
            reader = csv.DictReader(handle, fieldnames=first.split(","))
        for row in reader:
            cve = row["cve"]
            if cve not in wanted:
                continue
            percentile = row.get("percentile")
            found[cve] = (
                float(row["epss"]),
                float(percentile) if percentile not in (None, "") else None,
            )
    return found


def build_landmark_cohort(
    cohort: list[dict],
    epss_dir: Path,
    landmark_days: int,
    censor_date: date,
) -> tuple[pd.DataFrame, dict]:
    paths = sorted(epss_dir.glob("epss_scores-*.csv.gz"), key=snapshot_date)
    dates = [snapshot_date(path) for path in paths]
    metadata = {path: snapshot_metadata(path) for path in paths}
    assignments: dict[Path, list[dict]] = defaultdict(list)

    flow = {
        "input_rows": len(cohort),
        "prepublication_kev": 0,
        "same_day_kev": 0,
        "kev_on_or_before_landmark": 0,
        "landmark_after_censor": 0,
        "no_valid_snapshot": 0,
        "missing_epss": 0,
        "kev_after_censor_treated_censored": 0,
    }

    for row in cohort:
        published = row["published_date"]
        kev_date = row["kev_date_added"]
        if kev_date is not None and kev_date < published:
            flow["prepublication_kev"] += 1
            continue
        if kev_date == published:
            flow["same_day_kev"] += 1

        landmark = published + timedelta(days=landmark_days)
        if landmark >= censor_date:
            flow["landmark_after_censor"] += 1
            continue
        if kev_date is not None and kev_date <= landmark:
            flow["kev_on_or_before_landmark"] += 1
            continue

        idx = bisect.bisect_right(dates, landmark) - 1
        if idx < 0 or dates[idx] < published:
            flow["no_valid_snapshot"] += 1
            continue
        assignments[paths[idx]].append({**row, "landmark_date": landmark})

    rows: list[dict] = []
    for path, assigned in assignments.items():
        scored = load_selected_scores(path, {row["cve_id"] for row in assigned})
        score_date = snapshot_date(path)
        model_version = metadata[path].get("model_version", "unknown")
        for row in assigned:
            score = scored.get(row["cve_id"])
            if score is None:
                flow["missing_epss"] += 1
                continue
            epss, percentile = score
            kev_date = row["kev_date_added"]
            observed_event = bool(
                kev_date is not None
                and row["landmark_date"] < kev_date <= censor_date
            )
            if kev_date is not None and kev_date > censor_date:
                flow["kev_after_censor_treated_censored"] += 1
            end_date = kev_date if observed_event else censor_date
            duration = (end_date - row["landmark_date"]).days
            if duration <= 0:
                raise ValueError(f"Nonpositive follow-up for {row['cve_id']}")
            rows.append(
                {
                    "cve_id": row["cve_id"],
                    "published_date": row["published_date"].isoformat(),
                    "publication_year": row["published_date"].year,
                    "landmark_date": row["landmark_date"].isoformat(),
                    "epss_snapshot_date": score_date.isoformat(),
                    "epss_model_version": model_version,
                    "score_age_days": (row["landmark_date"] - score_date).days,
                    "epss": epss,
                    "epss_percentile": percentile,
                    "kev_date_added": kev_date.isoformat() if kev_date else "",
                    "event": int(observed_event),
                    "followup_days": duration,
                }
            )

    frame = pd.DataFrame(rows)
    flow["analysis_rows"] = int(len(frame))
    flow["observed_events"] = int(frame["event"].sum()) if not frame.empty else 0
    return frame, flow


def transform_score(frame: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    result = frame.copy()
    clipped = result["epss"].clip(1e-6, 1 - 1e-6)
    result["logit_epss"] = np.log(clipped / (1 - clipped))
    mean = float(result["logit_epss"].mean())
    sd = float(result["logit_epss"].std(ddof=0))
    result["z_logit_epss"] = (result["logit_epss"] - mean) / sd
    return result, {"logit_epss_mean": mean, "logit_epss_sd": sd}


def fit_survival_models(frame: pd.DataFrame) -> dict:
    transformed, scaling = transform_score(frame)
    fit_frame = transformed[["followup_days", "event", "z_logit_epss"]].copy()

    lifelines_result = None
    ph_result = None
    try:
        cph = CoxPHFitter()
        cph.fit(
            fit_frame,
            duration_col="followup_days",
            event_col="event",
            formula="z_logit_epss",
            show_progress=False,
        )
        row = cph.summary.loc["z_logit_epss"]
        ph = proportional_hazard_test(cph, fit_frame, time_transform="rank")
        ph_row = ph.summary.loc["z_logit_epss"]
        lifelines_result = {
            "coefficient": float(row["coef"]),
            "standard_error": float(row["se(coef)"]),
            "hazard_ratio": float(row["exp(coef)"]),
            "ci95_low": float(row["exp(coef) lower 95%"]),
            "ci95_high": float(row["exp(coef) upper 95%"]),
            "wald_p": float(row["p"]),
            "concordance_index": float(cph.concordance_index_),
        }
        ph_result = {
            "test_statistic": float(ph_row["test_statistic"]),
            "p_value": float(ph_row["p"]),
        }
    except ConvergenceError as exc:
        lifelines_result = {"error": f"ConvergenceError: {exc}"}
        ph_result = {"error": "Unavailable because the lifelines fit did not converge."}

    y = Surv.from_arrays(
        event=transformed["event"].astype(bool).to_numpy(),
        time=transformed["followup_days"].astype(float).to_numpy(),
    )
    x = transformed[["z_logit_epss"]].to_numpy()
    sk_cox = CoxPHSurvivalAnalysis(alpha=0.0, ties="breslow", n_iter=100, tol=1e-9)
    sk_cox.fit(x, y)

    km = KaplanMeierFitter()
    km.fit(transformed["followup_days"], event_observed=transformed["event"])
    km_incidence = {
        str(h): float(1.0 - km.predict(h))
        for h in HORIZONS
    }

    return {
        "n": int(len(transformed)),
        "events": int(transformed["event"].sum()),
        "scaling": scaling,
        "lifelines_efron": lifelines_result,
        "scikit_survival_breslow": {
            "coefficient": float(sk_cox.coef_[0]),
            "hazard_ratio": float(math.exp(sk_cox.coef_[0])),
        },
        "proportional_hazard_test_rank": ph_result,
        "km_cumulative_incidence": km_incidence,
    }


def fixed_window_metrics(frame: pd.DataFrame) -> dict:
    output: dict[str, dict] = {}
    for horizon in HORIZONS:
        event_by_horizon = (
            (frame["event"] == 1) & (frame["followup_days"] <= horizon)
        ).astype(int)

        naive_labels = event_by_horizon
        complete_mask = (
            (frame["followup_days"] >= horizon)
            | ((frame["event"] == 1) & (frame["followup_days"] <= horizon))
        )
        complete_labels = event_by_horizon[complete_mask]
        complete_scores = frame.loc[complete_mask, "epss"]

        output[str(horizon)] = {
            "naive_all_unobserved_as_negative": {
                "n": int(len(frame)),
                "events": int(naive_labels.sum()),
                "event_rate": float(naive_labels.mean()),
                "auroc": float(roc_auc_score(naive_labels, frame["epss"])),
                "average_precision": float(
                    average_precision_score(naive_labels, frame["epss"])
                ),
            },
            "complete_followup_binary": {
                "n": int(complete_mask.sum()),
                "events": int(complete_labels.sum()),
                "event_rate": float(complete_labels.mean()),
                "auroc": float(roc_auc_score(complete_labels, complete_scores)),
                "average_precision": float(
                    average_precision_score(complete_labels, complete_scores)
                ),
            },
            "excluded_for_insufficient_followup": int((~complete_mask).sum()),
        }
    return output


def describe_frame(frame: pd.DataFrame) -> dict:
    ages = frame["score_age_days"]
    return {
        "n": int(len(frame)),
        "events": int(frame["event"].sum()),
        "event_rate": float(frame["event"].mean()),
        "score_age_days": {
            "min": int(ages.min()),
            "median": float(ages.median()),
            "p90": float(ages.quantile(0.90)),
            "max": int(ages.max()),
        },
        "publication_year_counts": {
            str(k): int(v)
            for k, v in frame["publication_year"].value_counts().sort_index().items()
        },
        "publication_year_events": {
            str(k): int(v)
            for k, v in frame.groupby("publication_year")["event"].sum().items()
        },
        "model_version_counts": {
            str(k): int(v)
            for k, v in frame["epss_model_version"].value_counts().items()
        },
    }


def markdown_report(payload: dict) -> str:
    full = payload["full_cohort"]
    v3 = payload["v3_cohort"]
    lines = [
        "# Strict publication+30-day landmark replication",
        "",
        f"Administrative censor date: **{payload['censor_date']}**.",
        "The prediction origin is exactly publication + 30 days; the predictor is the latest historical EPSS snapshot available on or before that date.",
        "",
        "## Cohort flow",
        "",
    ]
    for key, value in payload["flow"].items():
        lines.append(f"- {key}: **{value:,}**" if isinstance(value, int) else f"- {key}: **{value}**")
    lines += [
        "",
        "## Dedicated-package Cox replication",
        "",
        "| Analysis | N | Events | lifelines HR (Efron) | 95% CI | scikit-survival HR (Breslow) | PH test p |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    def model_row(label: str, block: dict) -> str:
        lf = block["survival"]["lifelines_efron"]
        sk = block["survival"]["scikit_survival_breslow"]
        ph = block["survival"]["proportional_hazard_test_rank"]
        if "error" in lf:
            lf_hr = "NA"
            lf_ci = "NA"
        else:
            lf_hr = f"{lf['hazard_ratio']:.3f}"
            lf_ci = f"{lf['ci95_low']:.3f}-{lf['ci95_high']:.3f}"
        ph_value = "NA" if "error" in ph else f"{ph['p_value']:.3g}"
        return (
            f"| {label} | {block['survival']['n']:,} | {block['survival']['events']:,} | "
            f"{lf_hr} | {lf_ci} | {sk['hazard_ratio']:.3f} | {ph_value} |"
        )

    for label, block in (("All EPSS versions", full), ("EPSS v3 only", v3)):
        lines.append(model_row(label, block))
    for version, block in payload["by_model_version"].items():
        lines.append(model_row(version, block))
    lines += [
        "",
        "## Full-cohort fixed-window diagnostics",
        "",
        "| Horizon | Naive N | Naive AUROC | Complete N | Complete AUROC | Complete AP | Insufficient follow-up |",
        "|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for horizon, item in full["fixed_window"].items():
        naive = item["naive_all_unobserved_as_negative"]
        complete = item["complete_followup_binary"]
        lines.append(
            f"| {horizon} | {naive['n']:,} | {naive['auroc']:.3f} | "
            f"{complete['n']:,} | {complete['auroc']:.3f} | {complete['average_precision']:.5f} | "
            f"{item['excluded_for_insufficient_followup']:,} |"
        )
    lines += [
        "",
        "## Guardrails",
        "",
        "- The event is CISA KEV catalog inclusion, not first exploitation.",
        "- CVEs already in KEV by the exact landmark are excluded from the risk set.",
        "- CVEs without an observed event remain right-censored.",
        "- The full-cohort Cox estimate mixes EPSS model versions and is descriptive; the v3-only analysis is the preferred version-stable result.",
        "- A significant proportional-hazards test requires a time-varying-effect sensitivity analysis before relying on one constant hazard ratio.",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.processed_dir.mkdir(parents=True, exist_ok=True)

    cohort = load_cohort(args.cohort)
    frame, flow = build_landmark_cohort(
        cohort,
        args.epss_dir,
        landmark_days=args.landmark_days,
        censor_date=args.censor_date,
    )
    frame = frame.sort_values(["published_date", "cve_id"]).reset_index(drop=True)
    v3 = frame.loc[frame["epss_model_version"] == V3_MODEL_VERSION].copy()
    by_model_version = {}
    for version, version_frame in frame.groupby("epss_model_version", sort=True):
        by_model_version[str(version)] = {
            "description": describe_frame(version_frame),
            "survival": fit_survival_models(version_frame),
            "fixed_window": fixed_window_metrics(version_frame),
        }

    payload = {
        "censor_date": args.censor_date.isoformat(),
        "landmark_days": args.landmark_days,
        "flow": flow,
        "full_cohort": {
            "description": describe_frame(frame),
            "survival": fit_survival_models(frame),
            "fixed_window": fixed_window_metrics(frame),
        },
        "v3_cohort": {
            "description": describe_frame(v3),
            "survival": fit_survival_models(v3),
            "fixed_window": fixed_window_metrics(v3),
        },
        "by_model_version": by_model_version,
    }

    cohort_path = args.processed_dir / "strict_landmark30_cohort.csv.gz"
    frame.to_csv(cohort_path, index=False, compression="gzip")
    json_path = args.output_dir / "strict_landmark30_replication.json"
    md_path = args.output_dir / "strict_landmark30_replication.md"
    json_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    md_path.write_text(markdown_report(payload), encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
