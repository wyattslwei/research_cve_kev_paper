# Analysis plan v1.0: strict landmark and temporal validation

Date: 2026-07-18

Status: **post-feasibility finalization**. Protocol v0.2 was written before the dedicated-package and temporal-validation runs. This document records the exact primary implementation and distinguishes prespecified analyses from post-pilot additions. It is not represented as a prospective registration.

## Primary estimand and event

The event is first observed inclusion in the frozen CISA KEV catalog (`dateAdded`), not first exploitation. The primary estimand is discrimination and calibration of the point-in-time EPSS percentile for subsequent KEV inclusion among CVEs event-free 30 days after NVD publication.

## Exact landmark cohort

- Population: NVD CVEs published from 2022-01-01 through 2025-12-31.
- Landmark: exactly 30 calendar days after NVD publication.
- Exposure: most recent historical EPSS snapshot on or before the landmark and not before publication.
- Exclude: KEV inclusion before publication; KEV inclusion on or before the landmark; missing EPSS at the landmark.
- Follow-up origin: the 30-day landmark.
- Administrative censoring: 2026-07-16.
- CVEs without observed post-landmark KEV inclusion remain right-censored.

## Primary temporal evaluation

- Development: publication years 2022-2023.
- External validation: 2024.
- Locked test: 2025.
- Cross-version ranking variable: historical EPSS percentile.
- Calibration model: Cox proportional hazards with development-standardized logit(EPSS percentile), fit only on 2022-2023.
- Horizons: 30, 90, 180, and 365 days after the landmark.

Primary performance metrics:

1. cumulative/dynamic AUC at each horizon;
2. Uno C at 365 days;
3. IPCW Brier score and integrated Brier score from 30 to 365 days;
4. calibration slope and observed/predicted risk;
5. 95% percentile intervals from 500 publication-month block-bootstrap samples, conditioning on the locked development model.

One bootstrap draw can be undefined when a sampled external period contains no case/control configuration at a requested horizon. Such a draw is excluded as a whole and the valid replicate count is reported.

## EPSS model-version analysis

Raw EPSS scales are not pooled for a primary hazard-ratio interpretation. Within each EPSS model version, logit(raw EPSS) is standardized using that version's full analysis sample. A Breslow-ties Cox model estimates the hazard ratio per one fixed version-specific standard deviation. Confidence intervals use 500 publication-month block-bootstrap refits. Point estimates must agree with scikit-survival within an absolute coefficient tolerance of `1e-6`.

## Fixed-window comparison

For each horizon, the conventional naive analysis codes every CVE without an observed event by that horizon as a negative. The complete-follow-up analysis includes CVEs followed through the horizon plus CVEs with an event by the horizon. Report naive-minus-complete AUROC and average precision with month-block bootstrap intervals. Do not claim material bias when the interval includes zero.

## Operational evaluation

On validation/test periods, rank CVEs using historical EPSS percentile. Report top 0.5%, 1%, and 5% recall and monthly capacities of 100, 500, and 1,000 CVEs. A horizon includes only publication months in which all individual outcomes are ascertainable by that horizon. Report captured events, recall, precision, lift, number needed to review, and days from landmark to KEV inclusion among captured events.

## Prespecified sensitivity analyses

- Deliberately use the 2026-07-01 EPSS snapshot as a labeled negative-control leakage condition; it is never a deployable predictor.
- Contrast raw EPSS and percentile metrics across model-version transitions.
- Report score-snapshot age.
- Exclude versus day-1 coding for same-day events and separately describe pre-publication KEV records.
- Weekly versus monthly historical snapshots only if weekly data can be versioned and processed before manuscript freeze.

## Reporting rules

- Use “KEV inclusion,” never “true exploitation time.”
- Keep association, discrimination, calibration, and operational utility as separate claims.
- Do not describe right-censored CVEs as confirmed negatives.
- Do not use the future-snapshot negative control as evidence of attainable model performance.
- Do not select one favorable horizon and suppress the others.
- Treat capacity results as workload scenarios, not an organization's realized patch effectiveness.

